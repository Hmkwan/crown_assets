-- PostgreSQL database dump (Python implementation)
-- Dump date: 2025-12-05 07:46:24.877665


-- Table: account_request
DROP TABLE IF EXISTS account_request CASCADE;
CREATE TABLE account_request (
    id integer DEFAULT nextval('account_request_id_seq'::regclass) NOT NULL,
    username character varying(64),
    full_name character varying(120),
    employee_no character varying(64),
    email character varying(120),
    department character varying(120),
    role_requested character varying(64),
    reason text,
    password_hash character varying(128),
    status character varying(32),
    created_date timestamp without time zone,
    processed_date timestamp without time zone,
    approver_id integer,
    approver_comments text
);


-- Table: action_log
DROP TABLE IF EXISTS action_log CASCADE;
CREATE TABLE action_log (
    id integer DEFAULT nextval('action_log_id_seq'::regclass) NOT NULL,
    action_name character varying(120),
    workflow_node_id integer,
    approval_workflow_id integer,
    payload text,
    status character varying(32),
    result text,
    executed_at timestamp without time zone,
    retry_count integer
);


-- Table: announcements
DROP TABLE IF EXISTS announcements CASCADE;
CREATE TABLE announcements (
    id integer DEFAULT nextval('announcements_id_seq'::regclass) NOT NULL,
    title character varying(200) NOT NULL,
    content text NOT NULL,
    type character varying(20) NOT NULL,
    priority character varying(20) NOT NULL,
    is_pinned boolean,
    is_published boolean,
    publish_time timestamp without time zone,
    expire_time timestamp without time zone,
    created_at timestamp without time zone,
    updated_at timestamp without time zone,
    creator_id integer NOT NULL
);

INSERT INTO announcements (id, title, content, type, priority, is_pinned, is_published, publish_time, expire_time, created_at, updated_at, creator_id) VALUES (1, '他', '测试', 'notice', 'normal', False, True, '2025-12-04T09:28:00', '2025-12-04T09:29:00', '2025-12-04T01:28:34.726189', '2025-12-04T01:28:34.726194', 1);


-- Table: app_user
DROP TABLE IF EXISTS app_user CASCADE;
CREATE TABLE app_user (
    id integer DEFAULT nextval('user_id_seq'::regclass) NOT NULL,
    username character varying(64),
    email character varying(120),
    password_hash character varying(256),
    role character varying(64),
    department_id integer,
    department character varying(120),
    is_active boolean,
    workflow_roles text,
    can_manage_equipment boolean,
    can_manage_spare_parts boolean,
    can_manage_repairs boolean,
    can_manage_part_requests boolean,
    can_view_workflow boolean,
    can_edit_workflow boolean,
    can_manage_workflow_templates boolean,
    can_view_reports boolean,
    can_view_logs boolean
);

INSERT INTO app_user (id, username, email, password_hash, role, department_id, department, is_active, workflow_roles, can_manage_equipment, can_manage_spare_parts, can_manage_repairs, can_manage_part_requests, can_view_workflow, can_edit_workflow, can_manage_workflow_templates, can_view_reports, can_view_logs) VALUES (2, '陈松', 'chens@crown.com.cn', 'pbkdf2:sha256:260000$vyWSsqAfbqUXwpaQ$3a97b9445e94acb40a3d292908355bf9fee21aa5680ef0290447db4745354cba', 'admin', 6, '企管部', True, '["department_head"]', False, False, False, False, False, False, False, False, False);
INSERT INTO app_user (id, username, email, password_hash, role, department_id, department, is_active, workflow_roles, can_manage_equipment, can_manage_spare_parts, can_manage_repairs, can_manage_part_requests, can_view_workflow, can_edit_workflow, can_manage_workflow_templates, can_view_reports, can_view_logs) VALUES (4, '吴文杨', 'wuwy@crown.com.cn', 'pbkdf2:sha256:260000$QKNfhfKRn1KGCJFE$ea3c0e1a41dcbc243d35baa063822dfeffd5886396864f82601a562634f22b8c', 'admin', 1, '信息部', True, '["admin", "security"]', False, False, False, False, False, False, False, False, False);
INSERT INTO app_user (id, username, email, password_hash, role, department_id, department, is_active, workflow_roles, can_manage_equipment, can_manage_spare_parts, can_manage_repairs, can_manage_part_requests, can_view_workflow, can_edit_workflow, can_manage_workflow_templates, can_view_reports, can_view_logs) VALUES (5, '关鹤鸣', 'guanhem@crown.com.cn', 'pbkdf2:sha256:260000$WeyYCZoZWold6X7p$a3b659495e4ef4d64cbdae0d5dfba5642b5f97d4d5638486c790a63f88ec0fec', 'user', 1, '信息部', True, NULL, False, False, False, False, False, False, False, False, False);
INSERT INTO app_user (id, username, email, password_hash, role, department_id, department, is_active, workflow_roles, can_manage_equipment, can_manage_spare_parts, can_manage_repairs, can_manage_part_requests, can_view_workflow, can_edit_workflow, can_manage_workflow_templates, can_view_reports, can_view_logs) VALUES (6, '朱绪', 'zhux@crown.com.cn', 'pbkdf2:sha256:260000$7QpR7Ryz1LQ2gaw5$be711669eb54385b9617a4645acc11d943b418a441ab6f72a797bead865567df', 'user', 6, '企管部', True, NULL, False, False, False, False, False, False, False, False, False);
INSERT INTO app_user (id, username, email, password_hash, role, department_id, department, is_active, workflow_roles, can_manage_equipment, can_manage_spare_parts, can_manage_repairs, can_manage_part_requests, can_view_workflow, can_edit_workflow, can_manage_workflow_templates, can_view_reports, can_view_logs) VALUES (1, 'admin', 'admin@example.com', 'pbkdf2:sha256:260000$hslVB7kcN30GfRN0$d0bfebcdb755f2903cd976072059bb3f9631e223061ddbdeb8a40f2fcaa53db9', 'admin', 1, '信息部', True, NULL, False, False, False, False, False, False, False, False, False);
INSERT INTO app_user (id, username, email, password_hash, role, department_id, department, is_active, workflow_roles, can_manage_equipment, can_manage_spare_parts, can_manage_repairs, can_manage_part_requests, can_view_workflow, can_edit_workflow, can_manage_workflow_templates, can_view_reports, can_view_logs) VALUES (3, 'test_manager', 'test_manager@example.com', 'pbkdf2:sha256:260000$o9WcGF7mjM5e0f0m$982e9b88bcf2525b061051bcf51e710516fd861233c5bb769b66ad5fcc9c9669', 'department_manager', NULL, '测试部门', True, NULL, False, False, False, False, False, False, False, False, False);
INSERT INTO app_user (id, username, email, password_hash, role, department_id, department, is_active, workflow_roles, can_manage_equipment, can_manage_spare_parts, can_manage_repairs, can_manage_part_requests, can_view_workflow, can_edit_workflow, can_manage_workflow_templates, can_view_reports, can_view_logs) VALUES (7, '李卓富', 'lizf@qq.com', 'pbkdf2:sha256:260000$k7J07ePcD9C6L29j$1b6bc2cd93a11b04f34e583037a11f545f11d334fde1ae4c8358a4371001813b', 'admin', 1, '信息部', True, NULL, False, False, False, False, False, False, False, False, False);


-- Table: approval_decision
DROP TABLE IF EXISTS approval_decision CASCADE;
CREATE TABLE approval_decision (
    id integer DEFAULT nextval('approval_decision_id_seq'::regclass) NOT NULL,
    approval_workflow_id integer,
    approver_id integer,
    decision character varying(32),
    comments text,
    created_at timestamp without time zone
);


-- Table: approval_delegate
DROP TABLE IF EXISTS approval_delegate CASCADE;
CREATE TABLE approval_delegate (
    id integer DEFAULT nextval('approval_delegate_id_seq'::regclass) NOT NULL,
    user_id integer NOT NULL,
    delegate_to_id integer NOT NULL,
    order_types json,
    role_ids json,
    start_date timestamp without time zone NOT NULL,
    end_date timestamp without time zone NOT NULL,
    is_active boolean,
    reason text,
    created_date timestamp without time zone
);


-- Table: approval_instance
DROP TABLE IF EXISTS approval_instance CASCADE;
CREATE TABLE approval_instance (
    id integer DEFAULT nextval('approval_instance_id_seq'::regclass) NOT NULL,
    instance_no character varying(64) NOT NULL,
    template_id integer NOT NULL,
    order_type character varying(64) NOT NULL,
    order_id integer NOT NULL,
    requester_id integer NOT NULL,
    requester_dept_id integer,
    status character varying(32),
    current_node_id integer,
    started_date timestamp without time zone,
    completed_date timestamp without time zone,
    expected_complete_date timestamp without time zone,
    form_data json,
    context_data json,
    final_result character varying(32),
    final_comment text
);


-- Table: approval_log
DROP TABLE IF EXISTS approval_log CASCADE;
CREATE TABLE approval_log (
    id integer DEFAULT nextval('approval_log_id_seq'::regclass) NOT NULL,
    instance_id integer,
    step_id integer,
    action character varying(64) NOT NULL,
    operator_id integer,
    operator_role character varying(64),
    old_value json,
    new_value json,
    comment text,
    ip_address character varying(64),
    user_agent character varying(512),
    created_date timestamp without time zone
);


-- Table: approval_reminder
DROP TABLE IF EXISTS approval_reminder CASCADE;
CREATE TABLE approval_reminder (
    id integer DEFAULT nextval('approval_reminder_id_seq'::regclass) NOT NULL,
    step_id integer NOT NULL,
    reminder_type character varying(32),
    sent_to_id integer,
    sent_date timestamp without time zone,
    send_method character varying(32),
    is_sent boolean,
    sent_result text
);


-- Table: approval_role
DROP TABLE IF EXISTS approval_role CASCADE;
CREATE TABLE approval_role (
    id integer DEFAULT nextval('approval_role_id_seq'::regclass) NOT NULL,
    code character varying(64) NOT NULL,
    name character varying(120) NOT NULL,
    description text,
    category character varying(64),
    level integer,
    icon character varying(64),
    color character varying(32),
    can_approve_repair boolean,
    can_approve_part_request boolean,
    can_approve_equipment_transfer boolean,
    can_approve_equipment_scrap boolean,
    can_approve_equipment_loan boolean,
    can_approve_equipment_application boolean,
    max_approval_amount double precision,
    is_active boolean,
    is_system_role boolean,
    created_date timestamp without time zone,
    updated_date timestamp without time zone,
    created_by_id integer
);

INSERT INTO approval_role (id, code, name, description, category, level, icon, color, can_approve_repair, can_approve_part_request, can_approve_equipment_transfer, can_approve_equipment_scrap, can_approve_equipment_loan, can_approve_equipment_application, max_approval_amount, is_active, is_system_role, created_date, updated_date, created_by_id) VALUES (1, 'admin', '系统管理员', '拥有所有审批权限', 'system', 100, 'fa-user-tie', '#4e73df', True, True, True, True, True, True, NULL, True, True, '2025-12-03T14:10:21.514887', '2025-12-03T14:10:21.514894', NULL);
INSERT INTO approval_role (id, code, name, description, category, level, icon, color, can_approve_repair, can_approve_part_request, can_approve_equipment_transfer, can_approve_equipment_scrap, can_approve_equipment_loan, can_approve_equipment_application, max_approval_amount, is_active, is_system_role, created_date, updated_date, created_by_id) VALUES (2, 'department_head', '部门负责人', '部门主管,可审批部门内工单', 'system', 50, 'fa-user-tie', '#1cc88a', True, True, True, False, True, True, 10000.0, True, True, '2025-12-03T14:10:21.514897', '2025-12-03T14:10:21.514900', NULL);
INSERT INTO approval_role (id, code, name, description, category, level, icon, color, can_approve_repair, can_approve_part_request, can_approve_equipment_transfer, can_approve_equipment_scrap, can_approve_equipment_loan, can_approve_equipment_application, max_approval_amount, is_active, is_system_role, created_date, updated_date, created_by_id) VALUES (3, 'technician', '技术员', '技术人员,可审批维修相关工单', 'system', 30, 'fa-wrench', '#36b9cc', True, True, False, False, False, False, 5000.0, True, True, '2025-12-03T14:10:21.514902', '2025-12-03T14:10:21.514903', NULL);
INSERT INTO approval_role (id, code, name, description, category, level, icon, color, can_approve_repair, can_approve_part_request, can_approve_equipment_transfer, can_approve_equipment_scrap, can_approve_equipment_loan, can_approve_equipment_application, max_approval_amount, is_active, is_system_role, created_date, updated_date, created_by_id) VALUES (4, 'warehouse', '仓库管理员', '仓库管理人员,可审批配件相关工单', 'system', 30, 'fa-box', '#f6c23e', False, True, True, False, True, False, 3000.0, True, True, '2025-12-03T14:10:21.514905', '2025-12-03T14:10:21.514906', NULL);
INSERT INTO approval_role (id, code, name, description, category, level, icon, color, can_approve_repair, can_approve_part_request, can_approve_equipment_transfer, can_approve_equipment_scrap, can_approve_equipment_loan, can_approve_equipment_application, max_approval_amount, is_active, is_system_role, created_date, updated_date, created_by_id) VALUES (5, 'finance', '财务审批', '财务人员,可审批高金额工单', 'system', 70, 'fa-dollar-sign', '#e74a3b', True, True, True, True, False, True, NULL, True, True, '2025-12-03T14:10:21.514907', '2025-12-03T14:10:21.514909', NULL);


-- Table: approval_step
DROP TABLE IF EXISTS approval_step CASCADE;
CREATE TABLE approval_step (
    id integer DEFAULT nextval('approval_step_id_seq'::regclass) NOT NULL,
    instance_id integer NOT NULL,
    node_id integer NOT NULL,
    sequence integer NOT NULL,
    step_no character varying(64),
    approver_id integer,
    approver_role_id integer,
    assigned_date timestamp without time zone,
    parallel_group_id character varying(64),
    parallel_approvers json,
    approved_count integer,
    status character varying(32),
    result character varying(32),
    comment text,
    approved_date timestamp without time zone,
    transferred_from_id integer,
    transferred_to_id integer,
    transfer_reason text,
    deadline timestamp without time zone,
    is_timeout boolean,
    timeout_handled_date timestamp without time zone,
    admin_action character varying(32),
    admin_operator_id integer,
    admin_comment text
);


-- Table: approval_workflow
DROP TABLE IF EXISTS approval_workflow CASCADE;
CREATE TABLE approval_workflow (
    id integer DEFAULT nextval('approval_workflow_id_seq'::regclass) NOT NULL,
    order_type character varying(64),
    order_id integer,
    approver_id integer,
    approval_level character varying(64),
    node_id integer,
    status character varying(64),
    comments text,
    created_date timestamp without time zone,
    approved_date timestamp without time zone,
    auto_assigned boolean,
    action_type character varying(32),
    repair_cost_input double precision,
    transferred_from_id integer,
    admin_action character varying(32),
    admin_operator_id integer,
    required_approvals integer DEFAULT 1,
    actions_on_reject text
);

INSERT INTO approval_workflow (id, order_type, order_id, approver_id, approval_level, node_id, status, comments, created_date, approved_date, auto_assigned, action_type, repair_cost_input, transferred_from_id, admin_action, admin_operator_id, required_approvals, actions_on_reject) VALUES (18, 'equipment_loan', 3, 1, 'admin', NULL, 'approved', '', '2025-12-05T10:32:32.530944', '2025-12-05T10:33:33.771387', False, 'approve', NULL, NULL, NULL, NULL, 1, NULL);
INSERT INTO approval_workflow (id, order_type, order_id, approver_id, approval_level, node_id, status, comments, created_date, approved_date, auto_assigned, action_type, repair_cost_input, transferred_from_id, admin_action, admin_operator_id, required_approvals, actions_on_reject) VALUES (19, 'equipment_scrap', 1, 1, 'department_head', NULL, 'approved', '', '2025-12-05T10:41:04.803474', '2025-12-05T10:53:26.179260', True, 'approve', NULL, NULL, NULL, NULL, 1, NULL);
INSERT INTO approval_workflow (id, order_type, order_id, approver_id, approval_level, node_id, status, comments, created_date, approved_date, auto_assigned, action_type, repair_cost_input, transferred_from_id, admin_action, admin_operator_id, required_approvals, actions_on_reject) VALUES (1, 'repair_order', 2, 1, NULL, 1, 'approved', '管理员操作: 跳过此节点. 原因: ', '2025-12-03T16:43:02.003294', '2025-12-03T16:50:02.483716', False, 'approve', NULL, 1, 'skip', 1, 1, NULL);
INSERT INTO approval_workflow (id, order_type, order_id, approver_id, approval_level, node_id, status, comments, created_date, approved_date, auto_assigned, action_type, repair_cost_input, transferred_from_id, admin_action, admin_operator_id, required_approvals, actions_on_reject) VALUES (20, 'equipment_scrap', 1, 2, 'admin', NULL, 'approved', '管理员操作: 跳过此节点. 原因: ', '2025-12-05T10:41:05.803474', '2025-12-05T10:56:58.486684', False, 'approve', NULL, 1, 'skip', 1, 1, NULL);
INSERT INTO approval_workflow (id, order_type, order_id, approver_id, approval_level, node_id, status, comments, created_date, approved_date, auto_assigned, action_type, repair_cost_input, transferred_from_id, admin_action, admin_operator_id, required_approvals, actions_on_reject) VALUES (21, 'equipment_scrap', 1, NULL, NULL, 11, 'approved', '管理员操作: 跳过此节点. 原因: ', '2025-12-05T10:56:58.493730', '2025-12-05T10:57:23.749952', False, 'approve', NULL, NULL, 'skip', 1, 1, NULL);
INSERT INTO approval_workflow (id, order_type, order_id, approver_id, approval_level, node_id, status, comments, created_date, approved_date, auto_assigned, action_type, repair_cost_input, transferred_from_id, admin_action, admin_operator_id, required_approvals, actions_on_reject) VALUES (22, 'equipment_scrap', 1, NULL, NULL, 12, 'approved', '管理员操作: 跳过此节点. 原因: ', '2025-12-05T10:57:23.757667', '2025-12-05T11:07:46.941364', False, 'approve', NULL, NULL, 'skip', 1, 1, NULL);
INSERT INTO approval_workflow (id, order_type, order_id, approver_id, approval_level, node_id, status, comments, created_date, approved_date, auto_assigned, action_type, repair_cost_input, transferred_from_id, admin_action, admin_operator_id, required_approvals, actions_on_reject) VALUES (23, 'equipment_scrap', 1, NULL, NULL, 13, 'approved', '管理员操作: 跳过此节点. 原因: ', '2025-12-05T11:07:46.951785', '2025-12-05T12:04:22.780846', False, 'approve', NULL, NULL, 'skip', 1, 1, NULL);
INSERT INTO approval_workflow (id, order_type, order_id, approver_id, approval_level, node_id, status, comments, created_date, approved_date, auto_assigned, action_type, repair_cost_input, transferred_from_id, admin_action, admin_operator_id, required_approvals, actions_on_reject) VALUES (16, 'repair_order', 6, NULL, '部门负责人', 1, 'approved', '管理员操作: 跳过此节点. 原因: ', '2025-12-05T10:06:42.948608', '2025-12-05T12:05:39.610150', False, 'approve', NULL, NULL, 'skip', 1, 1, NULL);
INSERT INTO approval_workflow (id, order_type, order_id, approver_id, approval_level, node_id, status, comments, created_date, approved_date, auto_assigned, action_type, repair_cost_input, transferred_from_id, admin_action, admin_operator_id, required_approvals, actions_on_reject) VALUES (2, 'repair_order', 2, 1, NULL, 2, 'approved', '管理员操作: 跳过此节点. 原因: ', '2025-12-03T16:50:02.491258', '2025-12-03T17:07:10.281672', False, 'approve', NULL, NULL, 'skip', 1, 1, NULL);
INSERT INTO approval_workflow (id, order_type, order_id, approver_id, approval_level, node_id, status, comments, created_date, approved_date, auto_assigned, action_type, repair_cost_input, transferred_from_id, admin_action, admin_operator_id, required_approvals, actions_on_reject) VALUES (5, 'part_request_order', 2, 1, NULL, NULL, 'approved', '', '2025-12-04T09:30:33.301416', '2025-12-04T01:30:48.861624', True, 'approve', NULL, NULL, NULL, NULL, 1, NULL);
INSERT INTO approval_workflow (id, order_type, order_id, approver_id, approval_level, node_id, status, comments, created_date, approved_date, auto_assigned, action_type, repair_cost_input, transferred_from_id, admin_action, admin_operator_id, required_approvals, actions_on_reject) VALUES (6, 'part_request_order', 2, 1, NULL, NULL, 'approved', '', '2025-12-04T09:30:34.301416', '2025-12-04T01:30:49.808991', True, 'approve', NULL, NULL, NULL, NULL, 1, NULL);
INSERT INTO approval_workflow (id, order_type, order_id, approver_id, approval_level, node_id, status, comments, created_date, approved_date, auto_assigned, action_type, repair_cost_input, transferred_from_id, admin_action, admin_operator_id, required_approvals, actions_on_reject) VALUES (7, 'part_request_order', 2, 1, '仓库管理员', 7, 'approved', '', '2025-12-04T09:30:35.301416', '2025-12-04T01:30:52.117249', True, 'approve', NULL, NULL, NULL, NULL, 1, NULL);
INSERT INTO approval_workflow (id, order_type, order_id, approver_id, approval_level, node_id, status, comments, created_date, approved_date, auto_assigned, action_type, repair_cost_input, transferred_from_id, admin_action, admin_operator_id, required_approvals, actions_on_reject) VALUES (8, 'part_request_order', 2, NULL, NULL, 5, 'approved', '', '2025-12-04T09:30:48.868683', '2025-12-04T01:30:52.602751', False, 'approve', NULL, NULL, NULL, NULL, 1, NULL);
INSERT INTO approval_workflow (id, order_type, order_id, approver_id, approval_level, node_id, status, comments, created_date, approved_date, auto_assigned, action_type, repair_cost_input, transferred_from_id, admin_action, admin_operator_id, required_approvals, actions_on_reject) VALUES (9, 'part_request_order', 2, NULL, NULL, 5, 'approved', '', '2025-12-04T09:30:49.818591', '2025-12-04T01:30:53.153641', False, 'approve', NULL, NULL, NULL, NULL, 1, NULL);
INSERT INTO approval_workflow (id, order_type, order_id, approver_id, approval_level, node_id, status, comments, created_date, approved_date, auto_assigned, action_type, repair_cost_input, transferred_from_id, admin_action, admin_operator_id, required_approvals, actions_on_reject) VALUES (12, 'part_request_order', 2, NULL, NULL, 6, 'approved', '[管理员强制批准] ', '2025-12-04T09:30:53.157820', '2025-12-04T10:32:29.341186', False, 'approve', NULL, NULL, 'force_approve', 1, 1, NULL);
INSERT INTO approval_workflow (id, order_type, order_id, approver_id, approval_level, node_id, status, comments, created_date, approved_date, auto_assigned, action_type, repair_cost_input, transferred_from_id, admin_action, admin_operator_id, required_approvals, actions_on_reject) VALUES (11, 'part_request_order', 2, NULL, NULL, 6, 'approved', '[管理员强制批准] ', '2025-12-04T09:30:52.647183', '2025-12-04T10:32:32.456760', False, 'approve', NULL, NULL, 'force_approve', 1, 1, NULL);
INSERT INTO approval_workflow (id, order_type, order_id, approver_id, approval_level, node_id, status, comments, created_date, approved_date, auto_assigned, action_type, repair_cost_input, transferred_from_id, admin_action, admin_operator_id, required_approvals, actions_on_reject) VALUES (10, 'part_request_order', 2, NULL, NULL, 5, 'approved', '[管理员强制批准] ', '2025-12-04T09:30:52.121649', '2025-12-04T10:32:34.795811', False, 'approve', NULL, NULL, 'force_approve', 1, 1, NULL);
INSERT INTO approval_workflow (id, order_type, order_id, approver_id, approval_level, node_id, status, comments, created_date, approved_date, auto_assigned, action_type, repair_cost_input, transferred_from_id, admin_action, admin_operator_id, required_approvals, actions_on_reject) VALUES (4, 'repair_order', 3, NULL, NULL, 1, 'approved', '[管理员强制批准] ', '2025-12-03T17:15:32.302514', '2025-12-04T10:32:38.782947', False, 'approve', NULL, NULL, 'force_approve', 1, 1, NULL);
INSERT INTO approval_workflow (id, order_type, order_id, approver_id, approval_level, node_id, status, comments, created_date, approved_date, auto_assigned, action_type, repair_cost_input, transferred_from_id, admin_action, admin_operator_id, required_approvals, actions_on_reject) VALUES (3, 'repair_order', 2, NULL, NULL, 3, 'approved', '[管理员强制批准] ', '2025-12-03T17:07:10.293952', '2025-12-04T10:32:40.804356', False, 'approve', NULL, NULL, 'force_approve', 1, 1, NULL);
INSERT INTO approval_workflow (id, order_type, order_id, approver_id, approval_level, node_id, status, comments, created_date, approved_date, auto_assigned, action_type, repair_cost_input, transferred_from_id, admin_action, admin_operator_id, required_approvals, actions_on_reject) VALUES (13, 'equipment_loan', 2, 1, 'department_head', NULL, 'approved', '', '2025-12-04T16:43:53.099856', '2025-12-04T16:44:03.170518', True, 'approve', NULL, NULL, NULL, NULL, 1, NULL);
INSERT INTO approval_workflow (id, order_type, order_id, approver_id, approval_level, node_id, status, comments, created_date, approved_date, auto_assigned, action_type, repair_cost_input, transferred_from_id, admin_action, admin_operator_id, required_approvals, actions_on_reject) VALUES (14, 'equipment_loan', 2, 1, 'admin', NULL, 'approved', '', '2025-12-04T16:43:54.099856', '2025-12-04T16:44:07.365497', False, 'approve', NULL, NULL, NULL, NULL, 1, NULL);
INSERT INTO approval_workflow (id, order_type, order_id, approver_id, approval_level, node_id, status, comments, created_date, approved_date, auto_assigned, action_type, repair_cost_input, transferred_from_id, admin_action, admin_operator_id, required_approvals, actions_on_reject) VALUES (24, 'repair_order', 6, NULL, NULL, 2, 'approved', '管理员操作: 跳过此节点. 原因: ', '2025-12-05T12:05:39.624601', '2025-12-05T12:05:51.165200', False, 'approve', NULL, NULL, 'skip', 1, 1, NULL);
INSERT INTO approval_workflow (id, order_type, order_id, approver_id, approval_level, node_id, status, comments, created_date, approved_date, auto_assigned, action_type, repair_cost_input, transferred_from_id, admin_action, admin_operator_id, required_approvals, actions_on_reject) VALUES (15, 'repair_order', 5, 2, NULL, 1, 'approved', '[管理员强制批准] 出', '2025-12-05T09:07:33.512443', '2025-12-05T09:14:12.002887', False, 'approve', NULL, 2, 'force_approve', 1, 1, NULL);
INSERT INTO approval_workflow (id, order_type, order_id, approver_id, approval_level, node_id, status, comments, created_date, approved_date, auto_assigned, action_type, repair_cost_input, transferred_from_id, admin_action, admin_operator_id, required_approvals, actions_on_reject) VALUES (17, 'equipment_loan', 3, 1, 'department_head', NULL, 'approved', '', '2025-12-05T10:32:31.530944', '2025-12-05T10:33:32.941560', True, 'approve', NULL, NULL, NULL, NULL, 1, NULL);
INSERT INTO approval_workflow (id, order_type, order_id, approver_id, approval_level, node_id, status, comments, created_date, approved_date, auto_assigned, action_type, repair_cost_input, transferred_from_id, admin_action, admin_operator_id, required_approvals, actions_on_reject) VALUES (25, 'repair_order', 6, NULL, NULL, 3, 'approved', '管理员操作: 跳过此节点. 原因: ', '2025-12-05T12:05:51.171236', '2025-12-05T12:05:57.375998', False, 'approve', NULL, NULL, 'skip', 1, 1, NULL);
INSERT INTO approval_workflow (id, order_type, order_id, approver_id, approval_level, node_id, status, comments, created_date, approved_date, auto_assigned, action_type, repair_cost_input, transferred_from_id, admin_action, admin_operator_id, required_approvals, actions_on_reject) VALUES (26, 'repair_order', 6, NULL, NULL, NULL, 'approved', '管理员操作: 跳过此节点. 原因: ', '2025-12-05T12:05:57.384379', '2025-12-05T13:50:38.589835', False, 'approve', NULL, NULL, 'skip', 1, 1, NULL);


-- Table: asset_cost
DROP TABLE IF EXISTS asset_cost CASCADE;
CREATE TABLE asset_cost (
    id integer DEFAULT nextval('asset_cost_id_seq'::regclass) NOT NULL,
    equipment_id integer,
    purchase_price double precision,
    purchase_date date,
    maintenance_cost double precision,
    depreciation_rate double precision,
    residual_value double precision,
    depreciation_method character varying(64),
    expected_lifespan integer,
    supplier character varying(120),
    warranty_period integer,
    created_date timestamp without time zone,
    updated_date timestamp without time zone
);


-- Table: asset_handover
DROP TABLE IF EXISTS asset_handover CASCADE;
CREATE TABLE asset_handover (
    id integer DEFAULT nextval('asset_handover_id_seq'::regclass) NOT NULL,
    from_user_id integer,
    to_user_id integer,
    equipment_ids text,
    status character varying(64),
    reason character varying(64),
    reason_detail text,
    created_date timestamp without time zone,
    completed_date timestamp without time zone,
    completed_by_id integer
);


-- Table: asset_lifecycle
DROP TABLE IF EXISTS asset_lifecycle CASCADE;
CREATE TABLE asset_lifecycle (
    id integer DEFAULT nextval('asset_lifecycle_id_seq'::regclass) NOT NULL,
    equipment_id integer,
    event_type character varying(64),
    event_date timestamp without time zone,
    old_status character varying(64),
    new_status character varying(64),
    description text,
    responsible_user_id integer,
    cost_involved double precision,
    documents text
);


-- Table: audit_log
DROP TABLE IF EXISTS audit_log CASCADE;
CREATE TABLE audit_log (
    id integer DEFAULT nextval('audit_log_id_seq'::regclass) NOT NULL,
    user_id integer,
    action_type character varying(64),
    resource_type character varying(64),
    resource_id integer,
    old_value text,
    new_value text,
    ip_address character varying(64),
    reason text,
    created_date timestamp without time zone
);


-- Table: department
DROP TABLE IF EXISTS department CASCADE;
CREATE TABLE department (
    id integer DEFAULT nextval('department_id_seq'::regclass) NOT NULL,
    name character varying(120),
    code character varying(64),
    cost_center character varying(64),
    location character varying(120),
    description text
);

INSERT INTO department (id, name, code, cost_center, location, description) VALUES (1, '信息部', 'IT', 'CC001', 'A座5楼', '信息技术部门');
INSERT INTO department (id, name, code, cost_center, location, description) VALUES (2, '财务部', 'FIN', 'CC002', 'A座3楼', '财务管理部门');
INSERT INTO department (id, name, code, cost_center, location, description) VALUES (3, '人力行政部', 'HR', 'CC003', 'A座2楼', '人力资源部门');
INSERT INTO department (id, name, code, cost_center, location, description) VALUES (4, '国内销售中心', 'SALES', 'CC004', 'B座1楼', '销售部门');
INSERT INTO department (id, name, code, cost_center, location, description) VALUES (5, '生产办', 'PROD', 'CC005', 'C厂房', '生产制造部门');
INSERT INTO department (id, name, code, cost_center, location, description) VALUES (6, '企管部', 'ADMIN', 'CC006', 'A座4楼', '企业管理部门');


-- Table: equipment
DROP TABLE IF EXISTS equipment CASCADE;
CREATE TABLE equipment (
    id integer DEFAULT nextval('equipment_id_seq'::regclass) NOT NULL,
    name character varying(120),
    type_id integer,
    type character varying(64),
    brand character varying(64),
    model character varying(64),
    serial_number character varying(120),
    purchase_date date,
    price double precision,
    department_id integer,
    department character varying(120),
    location character varying(120),
    status character varying(64),
    is_public_pool boolean,
    require_return_inspection boolean DEFAULT false,
    allow_loan boolean DEFAULT true,
    equipment_number character varying(120)
);

INSERT INTO equipment (id, name, type_id, type, brand, model, serial_number, purchase_date, price, department_id, department, location, status, is_public_pool, require_return_inspection, allow_loan, equipment_number) VALUES (4, '宏碁笔记本高配', NULL, '电脑', '宏碁', '2047', '4', '2025-12-10', 4355.0, 1, '信息部', NULL, 'active', False, False, True, NULL);
INSERT INTO equipment (id, name, type_id, type, brand, model, serial_number, purchase_date, price, department_id, department, location, status, is_public_pool, require_return_inspection, allow_loan, equipment_number) VALUES (6, '宏碁笔记本高配', NULL, '电脑', '宏碁', '2049', '6', '2025-12-12', 1324.0, 1, '信息部', NULL, 'active', False, False, True, NULL);
INSERT INTO equipment (id, name, type_id, type, brand, model, serial_number, purchase_date, price, department_id, department, location, status, is_public_pool, require_return_inspection, allow_loan, equipment_number) VALUES (8, '宏碁笔记本高配', NULL, '电脑', '宏碁', '2051', '8', '2025-12-14', 6659.0, 1, '信息部', NULL, 'active', False, False, True, NULL);
INSERT INTO equipment (id, name, type_id, type, brand, model, serial_number, purchase_date, price, department_id, department, location, status, is_public_pool, require_return_inspection, allow_loan, equipment_number) VALUES (1, '宏碁笔记本高配', NULL, '电脑', '宏碁', '2044', '1', '2025-12-07', 1221.0, 1, '信息部', NULL, 'available', False, False, True, NULL);
INSERT INTO equipment (id, name, type_id, type, brand, model, serial_number, purchase_date, price, department_id, department, location, status, is_public_pool, require_return_inspection, allow_loan, equipment_number) VALUES (5, '宏碁笔记本高配', 2, '笔记本电脑', '宏碁', '2048', '5', '2025-12-11', 2455.0, 1, '信息部', NULL, 'active', False, False, True, NULL);
INSERT INTO equipment (id, name, type_id, type, brand, model, serial_number, purchase_date, price, department_id, department, location, status, is_public_pool, require_return_inspection, allow_loan, equipment_number) VALUES (9, '宏碁笔记本高配', 2, '笔记本电脑', '宏碁', '2032', '9', '2025-12-15', 6633.0, 1, '信息部', '信息部', 'active', True, False, True, NULL);
INSERT INTO equipment (id, name, type_id, type, brand, model, serial_number, purchase_date, price, department_id, department, location, status, is_public_pool, require_return_inspection, allow_loan, equipment_number) VALUES (10, '惠普154', 4, '打印机', '惠普', '2011', '10', '2011-11-07', 3365.0, 6, '企管部', '信息部', 'repair', False, False, True, NULL);
INSERT INTO equipment (id, name, type_id, type, brand, model, serial_number, purchase_date, price, department_id, department, location, status, is_public_pool, require_return_inspection, allow_loan, equipment_number) VALUES (7, '宏碁笔记本高配', NULL, '电脑', '宏碁', '2050', '7', '2020-12-13', 5255.0, 1, '信息部', NULL, 'repair', False, False, True, NULL);
INSERT INTO equipment (id, name, type_id, type, brand, model, serial_number, purchase_date, price, department_id, department, location, status, is_public_pool, require_return_inspection, allow_loan, equipment_number) VALUES (3, '宏碁笔记本高配', NULL, '电脑', '宏碁', '2046', '3', '2025-12-09', 1333.0, 1, '信息部', NULL, 'available', False, False, True, NULL);
INSERT INTO equipment (id, name, type_id, type, brand, model, serial_number, purchase_date, price, department_id, department, location, status, is_public_pool, require_return_inspection, allow_loan, equipment_number) VALUES (2, '宏碁笔记本高配', NULL, '电脑', '宏碁', '2045', '2', '2025-12-08', 1333.0, 1, '信息部', NULL, 'available', False, False, True, NULL);


-- Table: equipment_application
DROP TABLE IF EXISTS equipment_application CASCADE;
CREATE TABLE equipment_application (
    id integer DEFAULT nextval('equipment_application_id_seq'::regclass) NOT NULL,
    equipment_id integer,
    applicant_id integer,
    applicant_dept character varying(120),
    reason text,
    status character varying(64),
    created_date timestamp without time zone,
    approved_date timestamp without time zone
);


-- Table: equipment_loan
DROP TABLE IF EXISTS equipment_loan CASCADE;
CREATE TABLE equipment_loan (
    id integer DEFAULT nextval('equipment_loan_id_seq'::regclass) NOT NULL,
    equipment_id integer,
    requester_id integer,
    requester_dept character varying(120),
    start_date timestamp without time zone,
    end_date timestamp without time zone,
    status character varying(64),
    approved_by integer,
    approved_date timestamp without time zone,
    borrowed_date timestamp without time zone,
    returned_date timestamp without time zone,
    notes text,
    pickup_notified boolean,
    created_date timestamp without time zone,
    updated_date timestamp without time zone,
    return_request_date timestamp without time zone,
    return_notes text,
    return_condition character varying(64),
    inspected_by integer,
    inspection_date timestamp without time zone,
    inspection_notes text,
    inspection_result character varying(64),
    damage_compensation double precision DEFAULT 0,
    damage_description text
);

INSERT INTO equipment_loan (id, equipment_id, requester_id, requester_dept, start_date, end_date, status, approved_by, approved_date, borrowed_date, returned_date, notes, pickup_notified, created_date, updated_date, return_request_date, return_notes, return_condition, inspected_by, inspection_date, inspection_notes, inspection_result, damage_compensation, damage_description) VALUES (2, 3, 1, '信息部', '2025-12-05T16:43:00', '2025-12-06T18:43:00', 'returned', NULL, NULL, NULL, '2025-12-05T10:14:30.995754', '试试', False, '2025-12-04T16:43:53.097210', '2025-12-05T10:14:30.999194', '2025-12-05T10:14:30.995743', '', 'good', NULL, NULL, NULL, NULL, 0.0, NULL);
INSERT INTO equipment_loan (id, equipment_id, requester_id, requester_dept, start_date, end_date, status, approved_by, approved_date, borrowed_date, returned_date, notes, pickup_notified, created_date, updated_date, return_request_date, return_notes, return_condition, inspected_by, inspection_date, inspection_notes, inspection_result, damage_compensation, damage_description) VALUES (3, 2, 1, '信息部', '2025-12-05T10:32:00', '2025-12-05T10:32:00', 'returned', NULL, NULL, NULL, '2025-12-05T10:34:03.778501', '测试审批', False, '2025-12-05T10:32:31.527403', '2025-12-05T10:34:03.782539', '2025-12-05T10:34:03.778491', '', 'good', NULL, NULL, NULL, NULL, 0.0, NULL);


-- Table: equipment_scrap
DROP TABLE IF EXISTS equipment_scrap CASCADE;
CREATE TABLE equipment_scrap (
    id integer DEFAULT nextval('equipment_scrap_id_seq'::regclass) NOT NULL,
    equipment_id integer,
    requester_id integer,
    description text,
    status character varying(64),
    created_date timestamp without time zone,
    updated_date timestamp without time zone,
    disposal_method character varying(64),
    disposal_date timestamp without time zone,
    disposal_handler integer,
    disposal_notes text,
    disposal_value double precision DEFAULT 0.0,
    disposal_company character varying(200),
    financial_cleared boolean DEFAULT false,
    financial_cleared_date timestamp without time zone,
    financial_cleared_by integer,
    financial_notes text
);

INSERT INTO equipment_scrap (id, equipment_id, requester_id, description, status, created_date, updated_date, disposal_method, disposal_date, disposal_handler, disposal_notes, disposal_value, disposal_company, financial_cleared, financial_cleared_date, financial_cleared_by, financial_notes) VALUES (1, 7, 1, '的', 'approved', '2025-12-05T10:41:04.798764', '2025-12-05T12:04:22.796648', NULL, NULL, NULL, NULL, 0.0, NULL, False, NULL, NULL, NULL);


-- Table: equipment_transfer
DROP TABLE IF EXISTS equipment_transfer CASCADE;
CREATE TABLE equipment_transfer (
    id integer DEFAULT nextval('equipment_transfer_id_seq'::regclass) NOT NULL,
    equipment_id integer,
    from_department character varying(120),
    to_department character varying(120),
    requester_id integer,
    description text,
    status character varying(64),
    created_date timestamp without time zone,
    updated_date timestamp without time zone
);


-- Table: equipment_type
DROP TABLE IF EXISTS equipment_type CASCADE;
CREATE TABLE equipment_type (
    id integer DEFAULT nextval('equipment_type_id_seq'::regclass) NOT NULL,
    name character varying(120) NOT NULL,
    description text,
    created_date timestamp without time zone
);

INSERT INTO equipment_type (id, name, description, created_date) VALUES (1, '台式电脑', '台式办公电脑', '2025-12-03T12:46:00.932695');
INSERT INTO equipment_type (id, name, description, created_date) VALUES (2, '笔记本电脑', '笔记本办公电脑', '2025-12-03T12:46:00.935668');
INSERT INTO equipment_type (id, name, description, created_date) VALUES (3, '服务器', '服务器设备', '2025-12-03T12:46:00.937236');
INSERT INTO equipment_type (id, name, description, created_date) VALUES (4, '打印机', '激光/喷墨打印机', '2025-12-03T12:46:00.938660');
INSERT INTO equipment_type (id, name, description, created_date) VALUES (5, '扫描仪', '文档扫描设备', '2025-12-03T12:46:00.940107');
INSERT INTO equipment_type (id, name, description, created_date) VALUES (6, '投影仪', '会议投影设备', '2025-12-03T12:46:00.941943');
INSERT INTO equipment_type (id, name, description, created_date) VALUES (7, '显示器', '显示器设备', '2025-12-03T12:46:00.943895');
INSERT INTO equipment_type (id, name, description, created_date) VALUES (8, '路由器', '网络路由器', '2025-12-03T12:46:00.945413');
INSERT INTO equipment_type (id, name, description, created_date) VALUES (9, '交换机', '网络交换机', '2025-12-03T12:46:00.946821');
INSERT INTO equipment_type (id, name, description, created_date) VALUES (10, '防火墙', '网络安全设备', '2025-12-03T12:46:00.948254');
INSERT INTO equipment_type (id, name, description, created_date) VALUES (11, 'UPS电源', '不间断电源', '2025-12-03T12:46:00.950152');
INSERT INTO equipment_type (id, name, description, created_date) VALUES (12, '网络存储', 'NAS/SAN存储设备', '2025-12-03T12:46:00.951734');
INSERT INTO equipment_type (id, name, description, created_date) VALUES (13, '摄像头', '监控摄像设备', '2025-12-03T12:46:00.953481');
INSERT INTO equipment_type (id, name, description, created_date) VALUES (14, '会议设备', '会议系统设备', '2025-12-03T12:46:00.955118');
INSERT INTO equipment_type (id, name, description, created_date) VALUES (15, '电话设备', 'IP电话等通讯设备', '2025-12-03T12:46:00.957163');


-- Table: inventory_warning
DROP TABLE IF EXISTS inventory_warning CASCADE;
CREATE TABLE inventory_warning (
    id integer DEFAULT nextval('inventory_warning_id_seq'::regclass) NOT NULL,
    spare_part_id integer,
    min_threshold integer,
    critical_threshold integer,
    reorder_quantity integer,
    lead_time_days integer,
    enabled boolean,
    last_warned_date timestamp without time zone,
    created_date timestamp without time zone
);


-- Table: maintenance_plan
DROP TABLE IF EXISTS maintenance_plan CASCADE;
CREATE TABLE maintenance_plan (
    id integer DEFAULT nextval('maintenance_plan_id_seq'::regclass) NOT NULL,
    equipment_id integer NOT NULL,
    plan_name character varying(200),
    maintenance_type character varying(64),
    interval_days integer,
    next_maintenance_date date,
    last_maintenance_date date,
    responsible_person integer,
    description text,
    is_active boolean,
    created_by integer,
    created_date timestamp without time zone,
    updated_date timestamp without time zone
);


-- Table: maintenance_record
DROP TABLE IF EXISTS maintenance_record CASCADE;
CREATE TABLE maintenance_record (
    id integer DEFAULT nextval('maintenance_record_id_seq'::regclass) NOT NULL,
    plan_id integer,
    equipment_id integer NOT NULL,
    maintenance_date timestamp without time zone,
    maintenance_type character varying(64),
    performed_by integer,
    description text,
    notes text,
    cost double precision,
    next_maintenance_date date,
    status character varying(64),
    created_date timestamp without time zone
);


-- Table: notification
DROP TABLE IF EXISTS notification CASCADE;
CREATE TABLE notification (
    id integer DEFAULT nextval('notification_id_seq'::regclass) NOT NULL,
    user_id integer,
    title character varying(120),
    message text,
    is_read boolean,
    created_date timestamp without time zone,
    order_type character varying(64),
    order_id integer
);

INSERT INTO notification (id, user_id, title, message, is_read, created_date, order_type, order_id) VALUES (1, 1, '新维修工单', '用户 admin 提交了新的维修工单 #2', True, '2025-12-03T16:43:02.011359', NULL, NULL);
INSERT INTO notification (id, user_id, title, message, is_read, created_date, order_type, order_id) VALUES (2, 1, '新维修工单', '用户 admin 提交了新的维修工单 #3', True, '2025-12-03T17:15:32.311198', NULL, NULL);
INSERT INTO notification (id, user_id, title, message, is_read, created_date, order_type, order_id) VALUES (3, 1, '自动分配审批', '系统将 配件申请#2 的审批节点 None 自动分配给您，请尽快处理。', True, '2025-12-04T09:30:33.344945', NULL, NULL);
INSERT INTO notification (id, user_id, title, message, is_read, created_date, order_type, order_id) VALUES (4, 1, '自动分配审批', '系统将 配件申请#2 的审批节点 None 自动分配给您，请尽快处理。', True, '2025-12-04T09:30:33.352807', NULL, NULL);
INSERT INTO notification (id, user_id, title, message, is_read, created_date, order_type, order_id) VALUES (5, 1, '自动分配审批', '系统将 配件申请#2 的审批节点 仓库管理员 自动分配给您，请尽快处理。', True, '2025-12-04T09:30:33.360736', NULL, NULL);
INSERT INTO notification (id, user_id, title, message, is_read, created_date, order_type, order_id) VALUES (6, 1, '新配件申请', '用户 admin 提交了新的配件申请 #2', True, '2025-12-04T09:30:33.375451', NULL, NULL);
INSERT INTO notification (id, user_id, title, message, is_read, created_date, order_type, order_id) VALUES (7, 1, '配件申请审批状态更新', '您的配件申请 #2 已被 admin 批准', True, '2025-12-04T09:30:48.879568', 'part_request_order', 2);
INSERT INTO notification (id, user_id, title, message, is_read, created_date, order_type, order_id) VALUES (8, 1, '配件申请审批状态更新', '您的配件申请 #2 已被 admin 批准', True, '2025-12-04T09:30:49.832606', 'part_request_order', 2);
INSERT INTO notification (id, user_id, title, message, is_read, created_date, order_type, order_id) VALUES (9, 1, '配件申请审批状态更新', '您的配件申请 #2 已被 admin 批准', True, '2025-12-04T09:30:52.130518', 'part_request_order', 2);
INSERT INTO notification (id, user_id, title, message, is_read, created_date, order_type, order_id) VALUES (10, 1, '配件申请审批状态更新', '您的配件申请 #2 已被 admin 批准', True, '2025-12-04T09:30:52.656479', 'part_request_order', 2);
INSERT INTO notification (id, user_id, title, message, is_read, created_date, order_type, order_id) VALUES (11, 1, '配件申请审批状态更新', '您的配件申请 #2 已被 admin 批准', True, '2025-12-04T09:30:53.167928', 'part_request_order', 2);
INSERT INTO notification (id, user_id, title, message, is_read, created_date, order_type, order_id) VALUES (12, 1, '自动分配审批', '系统将 设备借用#2 的审批节点 部门领导 自动分配给您，请尽快处理。', True, '2025-12-04T16:43:53.114473', NULL, NULL);
INSERT INTO notification (id, user_id, title, message, is_read, created_date, order_type, order_id) VALUES (13, 1, '借用申请已提交', '您已提交设备借用申请 #2，等待审批。', True, '2025-12-04T16:43:53.124795', NULL, NULL);
INSERT INTO notification (id, user_id, title, message, is_read, created_date, order_type, order_id) VALUES (14, 1, '借用申请通过', '您的借用申请 #2 已审批通过', True, '2025-12-04T16:44:07.380856', NULL, NULL);
INSERT INTO notification (id, user_id, title, message, is_read, created_date, order_type, order_id) VALUES (17, 4, '新维修工单', '用户 朱绪 提交了新的维修工单 #5', False, '2025-12-05T09:07:33.520435', NULL, NULL);
INSERT INTO notification (id, user_id, title, message, is_read, created_date, order_type, order_id) VALUES (15, 1, '新维修工单', '用户 朱绪 提交了新的维修工单 #5', True, '2025-12-05T09:07:33.520412', NULL, NULL);
INSERT INTO notification (id, user_id, title, message, is_read, created_date, order_type, order_id) VALUES (23, 4, '新维修工单', '用户 admin 提交了新的维修工单 #6', False, '2025-12-05T10:06:42.959060', NULL, NULL);
INSERT INTO notification (id, user_id, title, message, is_read, created_date, order_type, order_id) VALUES (21, 1, '新维修工单', '用户 admin 提交了新的维修工单 #6', True, '2025-12-05T10:06:42.959012', NULL, NULL);
INSERT INTO notification (id, user_id, title, message, is_read, created_date, order_type, order_id) VALUES (24, 1, '自动分配审批', '系统将 设备借用#3 的审批节点 部门领导 自动分配给您，请尽快处理。', True, '2025-12-05T10:32:31.540184', NULL, NULL);
INSERT INTO notification (id, user_id, title, message, is_read, created_date, order_type, order_id) VALUES (25, 1, '借用申请已提交', '您已提交设备借用申请 #3，等待审批。', True, '2025-12-05T10:32:31.550405', NULL, NULL);
INSERT INTO notification (id, user_id, title, message, is_read, created_date, order_type, order_id) VALUES (26, 1, '借用申请通过', '您的借用申请 #3 已审批通过', True, '2025-12-05T10:33:33.790842', NULL, NULL);
INSERT INTO notification (id, user_id, title, message, is_read, created_date, order_type, order_id) VALUES (16, 2, '新维修工单', '用户 朱绪 提交了新的维修工单 #5', True, '2025-12-05T09:07:33.520427', NULL, NULL);
INSERT INTO notification (id, user_id, title, message, is_read, created_date, order_type, order_id) VALUES (18, 2, '审批已转交给您', '管理员 admin 将审批转交给您处理', True, '2025-12-05T09:12:14.496724', 'repair_order', 5);
INSERT INTO notification (id, user_id, title, message, is_read, created_date, order_type, order_id) VALUES (19, 2, '审批已转交给您', '管理员 admin 将审批转交给您处理', True, '2025-12-05T09:13:25.117959', 'repair_order', 5);
INSERT INTO notification (id, user_id, title, message, is_read, created_date, order_type, order_id) VALUES (20, 2, '审批已被管理员强制批准', '您负责的审批已被管理员 admin 强制批准', True, '2025-12-05T09:14:12.008614', 'repair_order', 5);
INSERT INTO notification (id, user_id, title, message, is_read, created_date, order_type, order_id) VALUES (22, 2, '新维修工单', '用户 admin 提交了新的维修工单 #6', True, '2025-12-05T10:06:42.959048', NULL, NULL);
INSERT INTO notification (id, user_id, title, message, is_read, created_date, order_type, order_id) VALUES (27, 1, '自动分配审批', '系统将 设备报废#1 的审批节点 部门领导 自动分配给您，请尽快处理。', True, '2025-12-05T10:41:04.815839', NULL, NULL);
INSERT INTO notification (id, user_id, title, message, is_read, created_date, order_type, order_id) VALUES (28, 1, '设备报废已提交', '您已提交设备报废申请 #1，等待审批流程。', True, '2025-12-05T10:41:04.826501', NULL, NULL);


-- Table: part_replacement
DROP TABLE IF EXISTS part_replacement CASCADE;
CREATE TABLE part_replacement (
    id integer DEFAULT nextval('part_replacement_id_seq'::regclass) NOT NULL,
    repair_order_id integer,
    spare_part_id integer,
    quantity integer,
    replacement_date timestamp without time zone
);


-- Table: part_request_order
DROP TABLE IF EXISTS part_request_order CASCADE;
CREATE TABLE part_request_order (
    id integer DEFAULT nextval('part_request_order_id_seq'::regclass) NOT NULL,
    requester_id integer,
    department_head_id integer,
    admin_id integer,
    part_name character varying(120),
    part_number character varying(120),
    quantity integer,
    reason text,
    status character varying(64),
    department_head_approved boolean,
    admin_approved boolean,
    created_date timestamp without time zone,
    updated_date timestamp without time zone,
    completed_date timestamp without time zone
);

INSERT INTO part_request_order (id, requester_id, department_head_id, admin_id, part_name, part_number, quantity, reason, status, department_head_approved, admin_approved, created_date, updated_date, completed_date) VALUES (2, 1, NULL, NULL, '内存11G', '1', 1, '2', 'approved', False, False, '2025-12-04T09:30:33.289929', '2025-12-04T10:32:29.346139', NULL);


-- Table: permission
DROP TABLE IF EXISTS permission CASCADE;
CREATE TABLE permission (
    id integer DEFAULT nextval('permission_id_seq'::regclass) NOT NULL,
    role_id integer,
    module character varying(64),
    action character varying(64),
    resource_type character varying(64),
    conditions text,
    is_granted boolean,
    priority integer,
    created_date timestamp without time zone
);

INSERT INTO permission (id, role_id, module, action, resource_type, conditions, is_granted, priority, created_date) VALUES (1, 1, 'report', 'view', NULL, NULL, True, 0, '2025-12-03T16:25:38.160464');


-- Table: repair_order
DROP TABLE IF EXISTS repair_order CASCADE;
CREATE TABLE repair_order (
    id integer DEFAULT nextval('repair_order_id_seq'::regclass) NOT NULL,
    equipment_id integer,
    requester_id integer,
    technician_id integer,
    department_head_id integer,
    admin_id integer,
    description text,
    repair_cost double precision,
    status character varying(64),
    created_date timestamp without time zone,
    updated_date timestamp without time zone,
    completed_date timestamp without time zone,
    department_head_approved boolean,
    admin_approved boolean
);

INSERT INTO repair_order (id, equipment_id, requester_id, technician_id, department_head_id, admin_id, description, repair_cost, status, created_date, updated_date, completed_date, department_head_approved, admin_approved) VALUES (1, 1, 1, NULL, NULL, NULL, '测试', 0.0, 'completed', '2025-12-03T16:38:48.585511', '2025-12-04T09:24:38.722538', '2025-12-04T09:24:38.722586', False, False);
INSERT INTO repair_order (id, equipment_id, requester_id, technician_id, department_head_id, admin_id, description, repair_cost, status, created_date, updated_date, completed_date, department_head_approved, admin_approved) VALUES (2, 1, 1, NULL, NULL, NULL, '测试', 0.0, 'approved', '2025-12-03T16:43:01.979193', '2025-12-04T10:32:40.807545', '2025-12-04T09:26:38.992051', False, False);
INSERT INTO repair_order (id, equipment_id, requester_id, technician_id, department_head_id, admin_id, description, repair_cost, status, created_date, updated_date, completed_date, department_head_approved, admin_approved) VALUES (5, 10, 6, NULL, NULL, NULL, '从', 0.0, 'approved', '2025-12-05T09:07:33.495159', '2025-12-05T09:14:12.010572', NULL, False, False);


-- Table: role_definition
DROP TABLE IF EXISTS role_definition CASCADE;
CREATE TABLE role_definition (
    id integer DEFAULT nextval('role_definition_id_seq'::regclass) NOT NULL,
    name character varying(64),
    description text,
    is_custom boolean,
    is_active boolean,
    created_date timestamp without time zone,
    created_by_id integer
);

INSERT INTO role_definition (id, name, description, is_custom, is_active, created_date, created_by_id) VALUES (1, '部门主管', '用户审批以及系统权限', True, True, '2025-12-03T16:01:33.167973', 1);


-- Table: spare_part
DROP TABLE IF EXISTS spare_part CASCADE;
CREATE TABLE spare_part (
    id integer DEFAULT nextval('spare_part_id_seq'::regclass) NOT NULL,
    name character varying(120),
    part_number character varying(120),
    type_id integer,
    price double precision,
    stock_quantity integer,
    min_stock_level integer,
    department_id integer,
    department character varying(120),
    location character varying(120),
    purchase_date date,
    is_public boolean
);

INSERT INTO spare_part (id, name, part_number, type_id, price, stock_quantity, min_stock_level, department_id, department, location, purchase_date, is_public) VALUES (1, '内存9G', 'me1002', 1, 2.0, 16, 10, NULL, '信息部', '信息部', '2025-11-05', False);
INSERT INTO spare_part (id, name, part_number, type_id, price, stock_quantity, min_stock_level, department_id, department, location, purchase_date, is_public) VALUES (2, '内存10G', 'me1003', 1, 663.0, 15, 10, NULL, '信息部', '信息部', '2025-11-01', False);
INSERT INTO spare_part (id, name, part_number, type_id, price, stock_quantity, min_stock_level, department_id, department, location, purchase_date, is_public) VALUES (3, '内存11G', '1', 1, 4.0, 18, 10, NULL, '信息部', '信息部', '2025-11-02', False);
INSERT INTO spare_part (id, name, part_number, type_id, price, stock_quantity, min_stock_level, department_id, department, location, purchase_date, is_public) VALUES (4, '内存11G', 'me1004', 1, 4.0, 18, 10, NULL, '信息部', '信息部', '2025-11-02', False);
INSERT INTO spare_part (id, name, part_number, type_id, price, stock_quantity, min_stock_level, department_id, department, location, purchase_date, is_public) VALUES (5, 'I5处理器', 'intei3', 5, 30.0, 19, 11, NULL, '信息部', '信息部', '2020-11-03', False);
INSERT INTO spare_part (id, name, part_number, type_id, price, stock_quantity, min_stock_level, department_id, department, location, purchase_date, is_public) VALUES (6, 'I6处理器', 'intei4', 5, 31.0, 20, 12, NULL, '信息部', '信息部', '2020-11-04', False);
INSERT INTO spare_part (id, name, part_number, type_id, price, stock_quantity, min_stock_level, department_id, department, location, purchase_date, is_public) VALUES (7, 'I7处理器', 'intei5', 5, 32.0, 21, 13, NULL, '信息部', '信息部', '2020-11-05', False);


-- Table: spare_part_type
DROP TABLE IF EXISTS spare_part_type CASCADE;
CREATE TABLE spare_part_type (
    id integer DEFAULT nextval('spare_part_type_id_seq'::regclass) NOT NULL,
    name character varying(120) NOT NULL,
    description text,
    created_date timestamp without time zone
);

INSERT INTO spare_part_type (id, name, description, created_date) VALUES (1, '内存条', '电脑内存条', '2025-12-03T12:46:00.963466');
INSERT INTO spare_part_type (id, name, description, created_date) VALUES (2, '硬盘', '机械硬盘/固态硬盘', '2025-12-03T12:46:00.966038');
INSERT INTO spare_part_type (id, name, description, created_date) VALUES (3, '电源', '电源适配器/电源模块', '2025-12-03T12:46:00.967857');
INSERT INTO spare_part_type (id, name, description, created_date) VALUES (4, '主板', '电脑主板', '2025-12-03T12:46:00.969462');
INSERT INTO spare_part_type (id, name, description, created_date) VALUES (5, 'CPU', '中央处理器', '2025-12-03T12:46:00.970877');
INSERT INTO spare_part_type (id, name, description, created_date) VALUES (6, '显卡', '图形处理器', '2025-12-03T12:46:00.973205');
INSERT INTO spare_part_type (id, name, description, created_date) VALUES (7, '散热器', 'CPU散热器', '2025-12-03T12:46:00.975145');
INSERT INTO spare_part_type (id, name, description, created_date) VALUES (8, '机箱风扇', '机箱散热风扇', '2025-12-03T12:46:00.976908');
INSERT INTO spare_part_type (id, name, description, created_date) VALUES (9, '网卡', '有线/无线网卡', '2025-12-03T12:46:00.978437');
INSERT INTO spare_part_type (id, name, description, created_date) VALUES (10, '声卡', '声卡设备', '2025-12-03T12:46:00.980004');
INSERT INTO spare_part_type (id, name, description, created_date) VALUES (11, '键盘', '键盘设备', '2025-12-03T12:46:00.981482');
INSERT INTO spare_part_type (id, name, description, created_date) VALUES (12, '鼠标', '鼠标设备', '2025-12-03T12:46:00.983282');
INSERT INTO spare_part_type (id, name, description, created_date) VALUES (13, '数据线', '各类数据传输线', '2025-12-03T12:46:00.985078');
INSERT INTO spare_part_type (id, name, description, created_date) VALUES (14, '网线', '网络连接线', '2025-12-03T12:46:00.986540');
INSERT INTO spare_part_type (id, name, description, created_date) VALUES (15, '电源线', '电源连接线', '2025-12-03T12:46:00.988539');
INSERT INTO spare_part_type (id, name, description, created_date) VALUES (16, '墨盒/硒鼓', '打印机耗材', '2025-12-03T12:46:00.990219');
INSERT INTO spare_part_type (id, name, description, created_date) VALUES (17, '打印纸', '打印用纸', '2025-12-03T12:46:00.991621');
INSERT INTO spare_part_type (id, name, description, created_date) VALUES (18, '投影灯泡', '投影仪灯泡', '2025-12-03T12:46:00.992994');
INSERT INTO spare_part_type (id, name, description, created_date) VALUES (19, '电池', 'UPS/设备电池', '2025-12-03T12:46:00.994344');
INSERT INTO spare_part_type (id, name, description, created_date) VALUES (20, '转接头', '各类转接器', '2025-12-03T12:46:00.995708');


-- Table: user_activity_log
DROP TABLE IF EXISTS user_activity_log CASCADE;
CREATE TABLE user_activity_log (
    id integer DEFAULT nextval('user_activity_log_id_seq'::regclass) NOT NULL,
    user_id integer,
    action character varying(120),
    description text,
    timestamp timestamp without time zone
);

INSERT INTO user_activity_log (id, user_id, action, description, timestamp) VALUES (1, 1, '用户登录', '用户 admin 登录系统', '2025-12-03T13:45:55.976140');
INSERT INTO user_activity_log (id, user_id, action, description, timestamp) VALUES (2, 1, '访问页面', '设备列表 (IP: 10.168.93.93)', '2025-12-03T13:55:05.574951');
INSERT INTO user_activity_log (id, user_id, action, description, timestamp) VALUES (3, 1, '访问页面', '设备类型管理 (IP: 10.168.93.93)', '2025-12-03T13:56:25.018842');
INSERT INTO user_activity_log (id, user_id, action, description, timestamp) VALUES (4, 1, '访问页面', '部门管理 (IP: 10.168.93.93)', '2025-12-03T14:06:41.235120');
INSERT INTO user_activity_log (id, user_id, action, description, timestamp) VALUES (5, 1, '访问页面', '资产/配件管理中心 (IP: 10.168.93.93)', '2025-12-03T14:06:48.513684');
INSERT INTO user_activity_log (id, user_id, action, description, timestamp) VALUES (6, 1, '访问页面', '公开仓库 (IP: 10.168.93.93)', '2025-12-03T14:07:01.986494');
INSERT INTO user_activity_log (id, user_id, action, description, timestamp) VALUES (7, 1, '用户登录', '用户 admin 登录系统', '2025-12-03T14:30:29.157828');
INSERT INTO user_activity_log (id, user_id, action, description, timestamp) VALUES (8, 1, '访问企业微信管理', '查看企业微信配置页面 (IP: 10.168.93.93)', '2025-12-03T14:31:24.346238');
INSERT INTO user_activity_log (id, user_id, action, description, timestamp) VALUES (9, 1, '管理公告', '访问公告管理页面 (IP: 10.168.93.93)', '2025-12-03T14:31:28.858040');
INSERT INTO user_activity_log (id, user_id, action, description, timestamp) VALUES (10, 1, '用户登录', '用户 admin 登录系统', '2025-12-03T14:38:03.923084');
INSERT INTO user_activity_log (id, user_id, action, description, timestamp) VALUES (11, 1, '用户登录', '用户 admin 登录系统', '2025-12-03T14:38:38.283139');
INSERT INTO user_activity_log (id, user_id, action, description, timestamp) VALUES (12, 1, '用户登录', '用户 admin 登录系统', '2025-12-03T15:57:17.184433');
INSERT INTO user_activity_log (id, user_id, action, description, timestamp) VALUES (13, 1, '用户登录', '用户 admin 登录系统', '2025-12-03T15:57:25.875508');
INSERT INTO user_activity_log (id, user_id, action, description, timestamp) VALUES (14, 1, '访问页面', '配件类型管理 (IP: 172.20.0.1)', '2025-12-03T15:57:33.781244');
INSERT INTO user_activity_log (id, user_id, action, description, timestamp) VALUES (15, 1, '访问企业微信管理', '查看企业微信配置页面 (IP: 172.20.0.1)', '2025-12-03T15:57:40.236714');
INSERT INTO user_activity_log (id, user_id, action, description, timestamp) VALUES (16, 1, '访问页面', '公开仓库 (IP: 172.20.0.1)', '2025-12-03T15:58:44.997474');
INSERT INTO user_activity_log (id, user_id, action, description, timestamp) VALUES (17, 1, '访问页面', '设备列表 (IP: 172.20.0.1)', '2025-12-03T15:58:48.321721');
INSERT INTO user_activity_log (id, user_id, action, description, timestamp) VALUES (18, 1, '导入设备', '导入 10 台，跳过 0 台 (IP: 172.20.0.1)', '2025-12-03T15:59:23.434432');
INSERT INTO user_activity_log (id, user_id, action, description, timestamp) VALUES (19, 1, '访问页面', '设备列表 (IP: 172.20.0.1)', '2025-12-03T15:59:25.476877');
INSERT INTO user_activity_log (id, user_id, action, description, timestamp) VALUES (20, 1, '打印标签', 'equipment#1 (IP: 172.20.0.1)', '2025-12-03T15:59:30.766319');
INSERT INTO user_activity_log (id, user_id, action, description, timestamp) VALUES (21, 1, '更新设备', '更新设备 惠普154#10 (IP: 172.20.0.1)', '2025-12-03T15:59:58.686702');
INSERT INTO user_activity_log (id, user_id, action, description, timestamp) VALUES (22, 1, '访问页面', '设备列表 (IP: 172.20.0.1)', '2025-12-03T15:59:58.755935');
INSERT INTO user_activity_log (id, user_id, action, description, timestamp) VALUES (23, 1, '打印标签', 'equipment#10 (IP: 172.20.0.1)', '2025-12-03T16:00:01.091412');
INSERT INTO user_activity_log (id, user_id, action, description, timestamp) VALUES (24, 1, '用户登录', '用户 admin 登录系统', '2025-12-03T16:00:31.374120');
INSERT INTO user_activity_log (id, user_id, action, description, timestamp) VALUES (25, 1, '创建角色', '创建自定义角色: 部门主管 (IP: 172.20.0.1)', '2025-12-03T16:01:33.177507');
INSERT INTO user_activity_log (id, user_id, action, description, timestamp) VALUES (26, 1, '配置权限', '配置角色"部门主管"的权限 (IP: 172.20.0.1)', '2025-12-03T16:01:37.368371');
INSERT INTO user_activity_log (id, user_id, action, description, timestamp) VALUES (27, 1, '创建用户', '管理员 admin 创建了用户 陈松 (IP: 172.20.0.1)', '2025-12-03T16:02:14.694538');
INSERT INTO user_activity_log (id, user_id, action, description, timestamp) VALUES (28, 1, '分配角色', '为角色"部门主管"分配了1个用户: 陈松 (IP: 172.20.0.1)', '2025-12-03T16:02:31.405474');
INSERT INTO user_activity_log (id, user_id, action, description, timestamp) VALUES (29, 1, '访问页面', '公开设备仓库 (IP: 172.20.0.1)', '2025-12-03T16:11:08.160446');
INSERT INTO user_activity_log (id, user_id, action, description, timestamp) VALUES (30, 1, '访问页面', '公开仓库 (IP: 172.20.0.1)', '2025-12-03T16:22:11.442001');
INSERT INTO user_activity_log (id, user_id, action, description, timestamp) VALUES (31, 1, '配置权限', '配置角色"部门主管"的权限 (IP: 172.20.0.1)', '2025-12-03T16:25:38.172131');
INSERT INTO user_activity_log (id, user_id, action, description, timestamp) VALUES (32, 1, '访问页面', '部门管理 (IP: 172.20.0.1)', '2025-12-03T16:29:18.057611');
INSERT INTO user_activity_log (id, user_id, action, description, timestamp) VALUES (33, 1, '访问页面', '资产/配件管理中心 (IP: 172.20.0.1)', '2025-12-03T16:31:27.635198');
INSERT INTO user_activity_log (id, user_id, action, description, timestamp) VALUES (34, 1, '生成二维码', 'equipment#1 (IP: 172.20.0.1)', '2025-12-03T16:31:30.183047');
INSERT INTO user_activity_log (id, user_id, action, description, timestamp) VALUES (35, 1, '访问页面', '设备列表 (IP: 172.20.0.1)', '2025-12-03T16:31:39.666377');
INSERT INTO user_activity_log (id, user_id, action, description, timestamp) VALUES (36, 1, '取消可申请', '设备 惠普154#10 取消可申请状态 (IP: 172.20.0.1)', '2025-12-03T16:31:48.338755');
INSERT INTO user_activity_log (id, user_id, action, description, timestamp) VALUES (37, 1, '访问页面', '设备列表 (IP: 172.20.0.1)', '2025-12-03T16:31:48.412233');
INSERT INTO user_activity_log (id, user_id, action, description, timestamp) VALUES (38, 1, '访问页面', '资产/配件管理中心 (IP: 172.20.0.1)', '2025-12-03T16:32:02.812704');
INSERT INTO user_activity_log (id, user_id, action, description, timestamp) VALUES (39, 1, '生成二维码', 'equipment#10 (IP: 172.20.0.1)', '2025-12-03T16:32:08.226027');
INSERT INTO user_activity_log (id, user_id, action, description, timestamp) VALUES (40, 1, '设备进入维修', '设备 宏碁笔记本高配 状态变更为维修中 (维修工单 #1) (IP: 172.20.0.1)', '2025-12-03T16:38:48.593457');
INSERT INTO user_activity_log (id, user_id, action, description, timestamp) VALUES (41, 1, '设备进入维修', '设备 宏碁笔记本高配 状态变更为维修中 (维修工单 #2) (IP: 172.20.0.1)', '2025-12-03T16:43:01.983719');
INSERT INTO user_activity_log (id, user_id, action, description, timestamp) VALUES (42, 1, '创建维修工单', '用户 admin 创建了维修工单 #2', '2025-12-03T16:43:02.005814');
INSERT INTO user_activity_log (id, user_id, action, description, timestamp) VALUES (43, 1, '访问页面', '配件列表 (IP: 172.20.0.1)', '2025-12-03T16:55:17.566848');
INSERT INTO user_activity_log (id, user_id, action, description, timestamp) VALUES (44, 1, '导入配件', '导入 7 个，跳过 0 个 (IP: 172.20.0.1)', '2025-12-03T16:55:39.120300');
INSERT INTO user_activity_log (id, user_id, action, description, timestamp) VALUES (45, 1, '访问页面', '配件列表 (IP: 172.20.0.1)', '2025-12-03T16:55:40.461836');
INSERT INTO user_activity_log (id, user_id, action, description, timestamp) VALUES (46, 1, '打印标签', 'spare_part#5 (IP: 172.20.0.1)', '2025-12-03T16:55:44.955886');
INSERT INTO user_activity_log (id, user_id, action, description, timestamp) VALUES (47, 1, '用户登录', '用户 admin 登录系统', '2025-12-03T17:06:55.168712');
INSERT INTO user_activity_log (id, user_id, action, description, timestamp) VALUES (48, 1, '用户登录', '用户 admin 登录系统', '2025-12-03T17:12:55.978859');
INSERT INTO user_activity_log (id, user_id, action, description, timestamp) VALUES (49, 1, '编辑用户', '管理员 admin 编辑了用户 admin (IP: 172.20.0.1)', '2025-12-03T17:14:41.381825');
INSERT INTO user_activity_log (id, user_id, action, description, timestamp) VALUES (50, 1, '设备进入维修', '设备 宏碁笔记本高配 状态变更为维修中 (维修工单 #3) (IP: 172.20.0.1)', '2025-12-03T17:15:32.284246');
INSERT INTO user_activity_log (id, user_id, action, description, timestamp) VALUES (51, 1, '创建维修工单', '用户 admin 创建了维修工单 #3', '2025-12-03T17:15:32.304969');
INSERT INTO user_activity_log (id, user_id, action, description, timestamp) VALUES (52, 1, '访问页面', '资产/配件管理中心 (IP: 172.20.0.1)', '2025-12-04T09:04:58.851990');
INSERT INTO user_activity_log (id, user_id, action, description, timestamp) VALUES (53, 1, '访问页面', '设备列表 (IP: 172.20.0.1)', '2025-12-04T09:05:00.553602');
INSERT INTO user_activity_log (id, user_id, action, description, timestamp) VALUES (54, 1, '访问页面', '设备列表 (IP: 172.20.0.1)', '2025-12-04T09:05:05.921004');
INSERT INTO user_activity_log (id, user_id, action, description, timestamp) VALUES (55, 1, '访问页面', '配件列表 (IP: 172.20.0.1)', '2025-12-04T09:07:58.077619');
INSERT INTO user_activity_log (id, user_id, action, description, timestamp) VALUES (56, 1, '访问页面', '设备类型管理 (IP: 172.20.0.1)', '2025-12-04T09:08:00.235561');
INSERT INTO user_activity_log (id, user_id, action, description, timestamp) VALUES (57, 1, '访问页面', '设备列表 (IP: 172.20.0.1)', '2025-12-04T09:10:56.884090');
INSERT INTO user_activity_log (id, user_id, action, description, timestamp) VALUES (58, 1, '访问页面', '设备列表 (IP: 172.20.0.1)', '2025-12-04T09:11:06.642039');
INSERT INTO user_activity_log (id, user_id, action, description, timestamp) VALUES (59, 1, '删除维修工单', '删除维修工单 #3 - 宏碁笔记本高配 (IP: 172.20.0.1)', '2025-12-04T09:17:40.008521');
INSERT INTO user_activity_log (id, user_id, action, description, timestamp) VALUES (60, 1, '维修完成', '设备 宏碁笔记本高配 维修完成,状态恢复为可用 (维修工单 #1) (IP: 172.20.0.1)', '2025-12-04T09:24:38.727179');
INSERT INTO user_activity_log (id, user_id, action, description, timestamp) VALUES (61, 1, '编辑维修工单', '编辑维修工单 #1 - 宏碁笔记本高配 -> 宏碁笔记本高配, 状态: 已提交 -> 已完成 (IP: 172.20.0.1)', '2025-12-04T09:24:38.742532');
INSERT INTO user_activity_log (id, user_id, action, description, timestamp) VALUES (62, 1, '维修完成', '设备 宏碁笔记本高配 维修完成,状态恢复为可用 (维修工单 #2) (IP: 172.20.0.1)', '2025-12-04T09:26:38.992565');
INSERT INTO user_activity_log (id, user_id, action, description, timestamp) VALUES (63, 1, '编辑维修工单', '编辑维修工单 #2 - 宏碁笔记本高配 -> 宏碁笔记本高配, 状态: 已提交 -> 已完成 (IP: 172.20.0.1)', '2025-12-04T09:26:39.003112');
INSERT INTO user_activity_log (id, user_id, action, description, timestamp) VALUES (64, 1, '访问页面', '配件列表 (IP: 172.20.0.1)', '2025-12-04T09:27:41.951522');
INSERT INTO user_activity_log (id, user_id, action, description, timestamp) VALUES (65, 1, '访问企业微信管理', '查看企业微信配置页面 (IP: 172.20.0.1)', '2025-12-04T09:28:11.829282');
INSERT INTO user_activity_log (id, user_id, action, description, timestamp) VALUES (66, 1, '管理公告', '访问公告管理页面 (IP: 172.20.0.1)', '2025-12-04T09:28:15.425684');
INSERT INTO user_activity_log (id, user_id, action, description, timestamp) VALUES (67, 1, '创建公告', '创建公告: 他 (ID: 1) (IP: 172.20.0.1)', '2025-12-04T09:28:34.742225');
INSERT INTO user_activity_log (id, user_id, action, description, timestamp) VALUES (68, 1, '管理公告', '访问公告管理页面 (IP: 172.20.0.1)', '2025-12-04T09:28:34.765898');
INSERT INTO user_activity_log (id, user_id, action, description, timestamp) VALUES (69, 1, '查看公告', '访问系统公告列表 (IP: 172.20.0.1)', '2025-12-04T09:28:38.689682');
INSERT INTO user_activity_log (id, user_id, action, description, timestamp) VALUES (70, 1, '查看公告', '访问系统公告列表 (IP: 172.20.0.1)', '2025-12-04T09:29:42.147334');
INSERT INTO user_activity_log (id, user_id, action, description, timestamp) VALUES (71, 1, '自动分配审批', '对于 配件申请#2 的审批节点 None，系统自动分配给管理员用户ID 1。', '2025-12-04T09:30:33.346720');
INSERT INTO user_activity_log (id, user_id, action, description, timestamp) VALUES (72, 1, '自动分配审批', '对于 配件申请#2 的审批节点 None，系统自动分配给管理员用户ID 1。', '2025-12-04T09:30:33.353882');
INSERT INTO user_activity_log (id, user_id, action, description, timestamp) VALUES (73, 1, '自动分配审批', '对于 配件申请#2 的审批节点 仓库管理员，系统自动分配给管理员用户ID 1。', '2025-12-04T09:30:33.361769');
INSERT INTO user_activity_log (id, user_id, action, description, timestamp) VALUES (74, 1, '创建配件申请', '用户 admin 创建了配件申请 #2', '2025-12-04T09:30:33.370250');
INSERT INTO user_activity_log (id, user_id, action, description, timestamp) VALUES (75, 1, '审批配件申请', '用户 admin 批准了配件申请 #2 (配件: 内存11G, 数量: 1) (IP: 172.20.0.1)', '2025-12-04T09:30:48.869893');
INSERT INTO user_activity_log (id, user_id, action, description, timestamp) VALUES (76, 1, '审批配件申请', '用户 admin 批准了配件申请 #2 (配件: 内存11G, 数量: 1) (IP: 172.20.0.1)', '2025-12-04T09:30:49.820630');
INSERT INTO user_activity_log (id, user_id, action, description, timestamp) VALUES (80, 1, '编辑配件申请', '编辑配件申请 #2 - 内存11G, 状态: 待审批 -> 部门领导已批准 (IP: 172.20.0.1)', '2025-12-04T09:31:37.977399');
INSERT INTO user_activity_log (id, user_id, action, description, timestamp) VALUES (77, 1, '审批配件申请', '用户 admin 批准了配件申请 #2 (配件: 内存11G, 数量: 1) (IP: 172.20.0.1)', '2025-12-04T09:30:52.122728');
INSERT INTO user_activity_log (id, user_id, action, description, timestamp) VALUES (79, 1, '审批配件申请', '用户 admin 批准了配件申请 #2 (配件: 内存11G, 数量: 1) (IP: 172.20.0.1)', '2025-12-04T09:30:53.159167');
INSERT INTO user_activity_log (id, user_id, action, description, timestamp) VALUES (78, 1, '审批配件申请', '用户 admin 批准了配件申请 #2 (配件: 内存11G, 数量: 1) (IP: 172.20.0.1)', '2025-12-04T09:30:52.648725');
INSERT INTO user_activity_log (id, user_id, action, description, timestamp) VALUES (81, 1, '访问页面', '配件类型管理 (IP: 172.20.0.1)', '2025-12-04T10:03:01.637230');
INSERT INTO user_activity_log (id, user_id, action, description, timestamp) VALUES (82, 1, '访问页面', '设备列表 (IP: 172.20.0.1)', '2025-12-04T10:03:15.669642');
INSERT INTO user_activity_log (id, user_id, action, description, timestamp) VALUES (83, 1, '访问页面', '资产/配件管理中心 (IP: 172.20.0.1)', '2025-12-04T10:04:16.879263');
INSERT INTO user_activity_log (id, user_id, action, description, timestamp) VALUES (84, 1, '生成二维码', 'equipment#2 (IP: 172.20.0.1)', '2025-12-04T10:04:20.229519');
INSERT INTO user_activity_log (id, user_id, action, description, timestamp) VALUES (85, 1, '生成二维码', 'equipment#1 (IP: 172.20.0.1)', '2025-12-04T10:04:24.988919');
INSERT INTO user_activity_log (id, user_id, action, description, timestamp) VALUES (86, 1, '生成二维码', 'equipment#4 (IP: 172.20.0.1)', '2025-12-04T10:04:27.313095');
INSERT INTO user_activity_log (id, user_id, action, description, timestamp) VALUES (87, 1, '生成二维码', 'equipment#7 (IP: 172.20.0.1)', '2025-12-04T10:04:29.203244');
INSERT INTO user_activity_log (id, user_id, action, description, timestamp) VALUES (88, 1, '生成二维码', 'equipment#8 (IP: 172.20.0.1)', '2025-12-04T10:04:29.661866');
INSERT INTO user_activity_log (id, user_id, action, description, timestamp) VALUES (89, 1, '生成二维码', 'equipment#9 (IP: 172.20.0.1)', '2025-12-04T10:04:31.042460');
INSERT INTO user_activity_log (id, user_id, action, description, timestamp) VALUES (90, 1, '生成二维码', 'equipment#10 (IP: 172.20.0.1)', '2025-12-04T10:04:33.691645');
INSERT INTO user_activity_log (id, user_id, action, description, timestamp) VALUES (91, 1, '访问页面', '部门管理 (IP: 172.20.0.1)', '2025-12-04T10:32:08.846269');
INSERT INTO user_activity_log (id, user_id, action, description, timestamp) VALUES (92, 1, '访问页面', '资产/配件管理中心 (IP: 172.20.0.1)', '2025-12-04T10:32:18.138693');
INSERT INTO user_activity_log (id, user_id, action, description, timestamp) VALUES (93, 1, '管理员干预', 'admin 强制批准了审批 #12', '2025-12-04T10:32:29.347297');
INSERT INTO user_activity_log (id, user_id, action, description, timestamp) VALUES (94, 1, '管理员干预', 'admin 强制批准了审批 #11', '2025-12-04T10:32:32.461221');
INSERT INTO user_activity_log (id, user_id, action, description, timestamp) VALUES (95, 1, '管理员干预', 'admin 强制批准了审批 #10', '2025-12-04T10:32:34.798558');
INSERT INTO user_activity_log (id, user_id, action, description, timestamp) VALUES (96, 1, '管理员干预', 'admin 强制批准了审批 #4', '2025-12-04T10:32:38.785729');
INSERT INTO user_activity_log (id, user_id, action, description, timestamp) VALUES (97, 1, '管理员干预', 'admin 强制批准了审批 #3', '2025-12-04T10:32:40.808767');
INSERT INTO user_activity_log (id, user_id, action, description, timestamp) VALUES (98, 1, '访问页面', '设备列表 (IP: 172.20.0.1)', '2025-12-04T13:45:05.091934');
INSERT INTO user_activity_log (id, user_id, action, description, timestamp) VALUES (99, 1, '访问页面', '设备列表 (IP: 172.20.0.1)', '2025-12-04T14:37:34.178698');
INSERT INTO user_activity_log (id, user_id, action, description, timestamp) VALUES (100, 1, '访问页面', '设备列表 (IP: 172.20.0.1)', '2025-12-04T14:37:39.291571');
INSERT INTO user_activity_log (id, user_id, action, description, timestamp) VALUES (101, 1, '更新设备', '更新设备 宏碁笔记本高配#5 (IP: 172.20.0.1)', '2025-12-04T14:37:55.198795');
INSERT INTO user_activity_log (id, user_id, action, description, timestamp) VALUES (102, 1, '访问页面', '设备列表 (IP: 172.20.0.1)', '2025-12-04T14:37:55.246319');
INSERT INTO user_activity_log (id, user_id, action, description, timestamp) VALUES (103, 1, '打印标签', 'equipment#1 (IP: 172.20.0.1)', '2025-12-04T14:37:58.233453');
INSERT INTO user_activity_log (id, user_id, action, description, timestamp) VALUES (104, 1, '访问页面', '设备列表 (IP: 172.20.0.1)', '2025-12-04T14:55:05.631908');
INSERT INTO user_activity_log (id, user_id, action, description, timestamp) VALUES (105, 1, '访问页面', '资产/配件管理中心 (IP: 172.20.0.1)', '2025-12-04T15:04:29.660018');
INSERT INTO user_activity_log (id, user_id, action, description, timestamp) VALUES (106, 1, '访问页面', '资产/配件管理中心 (IP: 172.20.0.1)', '2025-12-04T15:15:29.011076');
INSERT INTO user_activity_log (id, user_id, action, description, timestamp) VALUES (107, 1, '用户登录', '用户 admin 登录系统', '2025-12-04T16:11:38.404919');
INSERT INTO user_activity_log (id, user_id, action, description, timestamp) VALUES (108, 1, '用户登录', '用户 admin 登录系统', '2025-12-04T16:18:08.890697');
INSERT INTO user_activity_log (id, user_id, action, description, timestamp) VALUES (109, 1, '用户登录', '用户 admin 登录系统', '2025-12-04T16:25:11.132061');
INSERT INTO user_activity_log (id, user_id, action, description, timestamp) VALUES (110, 1, '手动触发定时任务', '管理员手动触发了定时任务: 检查待验收 (IP: 172.20.0.1)', '2025-12-04T16:38:23.020861');
INSERT INTO user_activity_log (id, user_id, action, description, timestamp) VALUES (111, 1, '自动分配审批', '对于 设备借用#2 的审批节点 部门领导，系统自动分配给管理员用户ID 1。', '2025-12-04T16:43:53.117365');
INSERT INTO user_activity_log (id, user_id, action, description, timestamp) VALUES (112, 1, '设备借出', '设备 宏碁笔记本高配 已借出给 admin (借用申请 #2) (IP: 172.20.0.1)', '2025-12-04T16:44:07.373080');
INSERT INTO user_activity_log (id, user_id, action, description, timestamp) VALUES (113, 1, '访问企业微信管理', '查看企业微信配置页面 (IP: 172.20.0.1)', '2025-12-04T16:48:40.874703');
INSERT INTO user_activity_log (id, user_id, action, description, timestamp) VALUES (114, 1, '访问页面', '公开设备仓库 (IP: 172.20.0.1)', '2025-12-04T16:49:44.757171');
INSERT INTO user_activity_log (id, user_id, action, description, timestamp) VALUES (115, 1, '访问页面', '公开仓库 (IP: 172.20.0.1)', '2025-12-04T17:12:08.427803');
INSERT INTO user_activity_log (id, user_id, action, description, timestamp) VALUES (116, 1, '访问页面', '设备列表 (IP: 172.20.0.1)', '2025-12-04T17:12:13.479915');
INSERT INTO user_activity_log (id, user_id, action, description, timestamp) VALUES (117, 1, '加入公开仓库', '设备 宏碁笔记本高配#9 加入信息部公开仓库 (IP: 172.20.0.1)', '2025-12-04T17:12:22.288266');
INSERT INTO user_activity_log (id, user_id, action, description, timestamp) VALUES (118, 1, '访问页面', '设备列表 (IP: 172.20.0.1)', '2025-12-04T17:12:22.355397');
INSERT INTO user_activity_log (id, user_id, action, description, timestamp) VALUES (119, 1, '编辑用户', '管理员 admin 编辑了用户 陈松 (IP: 172.20.0.1)', '2025-12-05T08:03:19.732764');
INSERT INTO user_activity_log (id, user_id, action, description, timestamp) VALUES (120, 1, '编辑用户', '管理员 admin 编辑了用户 陈松 (IP: 172.20.0.1)', '2025-12-05T08:16:00.229513');
INSERT INTO user_activity_log (id, user_id, action, description, timestamp) VALUES (121, 1, '用户登出', '用户 admin 登出系统', '2025-12-05T08:19:02.571972');
INSERT INTO user_activity_log (id, user_id, action, description, timestamp) VALUES (122, 2, '用户登录', '用户 陈松 登录系统', '2025-12-05T08:19:05.346372');
INSERT INTO user_activity_log (id, user_id, action, description, timestamp) VALUES (123, 1, '用户登录', '用户 admin 登录系统', '2025-12-05T08:30:55.211524');
INSERT INTO user_activity_log (id, user_id, action, description, timestamp) VALUES (124, 1, '用户登录', '用户 admin 登录系统', '2025-12-05T08:35:55.343300');
INSERT INTO user_activity_log (id, user_id, action, description, timestamp) VALUES (125, 1, '访问页面', '资产/配件管理中心 (IP: 172.20.0.1)', '2025-12-05T08:36:43.719765');
INSERT INTO user_activity_log (id, user_id, action, description, timestamp) VALUES (126, 1, '生成二维码', 'equipment#2 (IP: 172.20.0.1)', '2025-12-05T08:36:47.685482');
INSERT INTO user_activity_log (id, user_id, action, description, timestamp) VALUES (127, 1, '手动触发定时任务', '管理员手动触发了定时任务: 检查待审批事项 (IP: 172.20.0.1)', '2025-12-05T08:37:41.114535');
INSERT INTO user_activity_log (id, user_id, action, description, timestamp) VALUES (128, 1, '访问页面', '设备列表 (IP: 172.20.0.1)', '2025-12-05T08:38:50.079740');
INSERT INTO user_activity_log (id, user_id, action, description, timestamp) VALUES (129, 1, '访问页面', '公开仓库 (IP: 172.20.0.1)', '2025-12-05T08:38:54.414329');
INSERT INTO user_activity_log (id, user_id, action, description, timestamp) VALUES (130, 1, '访问页面', '公开仓库 (IP: 172.20.0.1)', '2025-12-05T08:38:57.712283');
INSERT INTO user_activity_log (id, user_id, action, description, timestamp) VALUES (131, 1, '访问页面', '公开仓库 (IP: 172.20.0.1)', '2025-12-05T08:39:04.295530');
INSERT INTO user_activity_log (id, user_id, action, description, timestamp) VALUES (132, 1, '访问页面', '设备列表 (IP: 172.20.0.1)', '2025-12-05T08:39:07.770723');
INSERT INTO user_activity_log (id, user_id, action, description, timestamp) VALUES (133, 1, '更新设备', '更新设备 宏碁笔记本高配#9 (IP: 172.20.0.1)', '2025-12-05T08:39:28.989131');
INSERT INTO user_activity_log (id, user_id, action, description, timestamp) VALUES (134, 1, '访问页面', '设备列表 (IP: 172.20.0.1)', '2025-12-05T08:39:29.034517');
INSERT INTO user_activity_log (id, user_id, action, description, timestamp) VALUES (135, 1, '打印标签', 'equipment#9 (IP: 172.20.0.1)', '2025-12-05T08:39:34.971983');
INSERT INTO user_activity_log (id, user_id, action, description, timestamp) VALUES (136, 1, '创建用户', '管理员 admin 创建了用户 吴文杨 (IP: 172.20.0.1)', '2025-12-05T08:42:38.017230');
INSERT INTO user_activity_log (id, user_id, action, description, timestamp) VALUES (137, 1, '创建用户', '管理员 admin 创建了用户 关鹤鸣 (IP: 172.20.0.1)', '2025-12-05T09:02:30.595259');
INSERT INTO user_activity_log (id, user_id, action, description, timestamp) VALUES (138, 1, '创建用户', '管理员 admin 创建了用户 朱绪 (IP: 172.20.0.1)', '2025-12-05T09:02:54.513820');
INSERT INTO user_activity_log (id, user_id, action, description, timestamp) VALUES (139, 6, '用户登录', '用户 朱绪 登录系统', '2025-12-05T09:07:06.880041');
INSERT INTO user_activity_log (id, user_id, action, description, timestamp) VALUES (140, 6, '设备进入维修', '设备 惠普154 状态变更为维修中 (维修工单 #5) (IP: 172.20.0.1)', '2025-12-05T09:07:33.501504');
INSERT INTO user_activity_log (id, user_id, action, description, timestamp) VALUES (141, 6, '创建维修工单', '用户 朱绪 创建了维修工单 #5', '2025-12-05T09:07:33.515036');
INSERT INTO user_activity_log (id, user_id, action, description, timestamp) VALUES (142, 2, '用户登录', '用户 陈松 登录系统', '2025-12-05T09:08:50.378204');
INSERT INTO user_activity_log (id, user_id, action, description, timestamp) VALUES (143, 1, '管理员干预', 'admin 将审批 #15 转交给 陈松', '2025-12-05T09:12:14.498224');
INSERT INTO user_activity_log (id, user_id, action, description, timestamp) VALUES (144, 1, '管理员干预', 'admin 将审批 #15 转交给 陈松', '2025-12-05T09:13:25.119551');
INSERT INTO user_activity_log (id, user_id, action, description, timestamp) VALUES (145, 1, '管理员干预', 'admin 强制批准了审批 #15', '2025-12-05T09:14:12.011807');
INSERT INTO user_activity_log (id, user_id, action, description, timestamp) VALUES (146, 2, '用户登出', '用户 陈松 登出系统', '2025-12-05T09:16:03.968840');
INSERT INTO user_activity_log (id, user_id, action, description, timestamp) VALUES (147, 1, '用户登录', '用户 admin 登录系统', '2025-12-05T09:38:43.980092');
INSERT INTO user_activity_log (id, user_id, action, description, timestamp) VALUES (148, 1, '访问页面', '设备列表 (IP: 172.20.0.1)', '2025-12-05T09:55:40.945098');
INSERT INTO user_activity_log (id, user_id, action, description, timestamp) VALUES (149, 1, '设备进入维修', '设备 宏碁笔记本高配 状态变更为维修中 (维修工单 #6) (IP: 172.20.0.1)', '2025-12-05T10:06:42.927878');
INSERT INTO user_activity_log (id, user_id, action, description, timestamp) VALUES (150, 1, '创建维修工单', '用户 admin 创建了维修工单 #6', '2025-12-05T10:06:42.950931');
INSERT INTO user_activity_log (id, user_id, action, description, timestamp) VALUES (151, 1, '编辑维修工单', '编辑维修工单 #6 - 宏碁笔记本高配 -> 宏碁笔记本高配, 状态: 已提交 -> 已提交 (IP: 172.20.0.1)', '2025-12-05T10:11:19.196907');
INSERT INTO user_activity_log (id, user_id, action, description, timestamp) VALUES (152, 1, '自动分配审批', '对于 设备借用#3 的审批节点 部门领导，系统自动分配给管理员用户ID 1。', '2025-12-05T10:32:31.543780');
INSERT INTO user_activity_log (id, user_id, action, description, timestamp) VALUES (153, 1, '设备借出', '设备 宏碁笔记本高配 已借出给 admin (借用申请 #3) (IP: 172.20.0.1)', '2025-12-05T10:33:33.782180');
INSERT INTO user_activity_log (id, user_id, action, description, timestamp) VALUES (154, 1, '删除维修工单', '删除维修工单 #6 - 宏碁笔记本高配 (IP: 172.20.0.1)', '2025-12-05T10:33:42.850691');
INSERT INTO user_activity_log (id, user_id, action, description, timestamp) VALUES (155, 1, '自动分配审批', '对于 设备报废#1 的审批节点 部门领导，系统自动分配给管理员用户ID 1。', '2025-12-05T10:41:04.817470');
INSERT INTO user_activity_log (id, user_id, action, description, timestamp) VALUES (156, 1, '审批设备报废', '用户 admin 批准了设备报废申请 #1 (IP: 172.20.0.1)', '2025-12-05T10:53:26.190893');
INSERT INTO user_activity_log (id, user_id, action, description, timestamp) VALUES (157, 1, '用户登出', '用户 admin 登出系统', '2025-12-05T10:55:06.628436');
INSERT INTO user_activity_log (id, user_id, action, description, timestamp) VALUES (158, 2, '用户登录', '用户 陈松 登录系统', '2025-12-05T10:55:09.636374');
INSERT INTO user_activity_log (id, user_id, action, description, timestamp) VALUES (159, 2, '用户登出', '用户 陈松 登出系统', '2025-12-05T10:56:15.283430');
INSERT INTO user_activity_log (id, user_id, action, description, timestamp) VALUES (160, 1, '用户登录', '用户 admin 登录系统', '2025-12-05T10:56:17.785181');
INSERT INTO user_activity_log (id, user_id, action, description, timestamp) VALUES (161, 1, '用户登录', '用户 admin 登录系统', '2025-12-05T11:19:36.379734');
INSERT INTO user_activity_log (id, user_id, action, description, timestamp) VALUES (162, 1, '重置密码', '管理员为用户 admin 重置密码 (IP: 172.20.0.1)', '2025-12-05T11:35:16.544091');
INSERT INTO user_activity_log (id, user_id, action, description, timestamp) VALUES (163, 1, '重置密码', '管理员为用户 test_manager 重置密码 (IP: 172.20.0.1)', '2025-12-05T11:41:10.950918');
INSERT INTO user_activity_log (id, user_id, action, description, timestamp) VALUES (164, 1, '访问页面', '公开仓库 (IP: 172.20.0.1)', '2025-12-05T14:06:43.169784');
INSERT INTO user_activity_log (id, user_id, action, description, timestamp) VALUES (165, 1, '访问页面', '公开仓库 (IP: 172.20.0.1)', '2025-12-05T14:06:44.862357');
INSERT INTO user_activity_log (id, user_id, action, description, timestamp) VALUES (166, 6, '用户登出', '用户 朱绪 登出系统', '2025-12-05T14:42:53.269764');
INSERT INTO user_activity_log (id, user_id, action, description, timestamp) VALUES (167, 1, '用户登录', '用户 admin 登录系统', '2025-12-05T14:54:06.148654');
INSERT INTO user_activity_log (id, user_id, action, description, timestamp) VALUES (168, 1, '创建用户', '管理员 admin 创建了用户 李卓富 (IP: 172.20.0.1)', '2025-12-05T14:54:38.993377');
INSERT INTO user_activity_log (id, user_id, action, description, timestamp) VALUES (169, 7, '用户登录', '用户 李卓富 登录系统', '2025-12-05T14:54:56.420357');
INSERT INTO user_activity_log (id, user_id, action, description, timestamp) VALUES (170, 7, '用户登录', '用户 李卓富 登录系统', '2025-12-05T15:06:41.494795');
INSERT INTO user_activity_log (id, user_id, action, description, timestamp) VALUES (171, 7, '访问页面', '设备列表 (IP: 172.20.0.1)', '2025-12-05T15:06:54.180824');
INSERT INTO user_activity_log (id, user_id, action, description, timestamp) VALUES (172, 7, '打印标签', 'equipment#2 (IP: 172.20.0.1)', '2025-12-05T15:07:00.761675');
INSERT INTO user_activity_log (id, user_id, action, description, timestamp) VALUES (173, 1, '访问企业微信管理', '查看企业微信配置页面 (IP: 172.20.0.1)', '2025-12-05T15:20:25.438661');
INSERT INTO user_activity_log (id, user_id, action, description, timestamp) VALUES (174, 1, '用户登录', '用户 admin 登录系统', '2025-12-05T15:38:41.082613');


-- Table: user_approval_role
DROP TABLE IF EXISTS user_approval_role CASCADE;
CREATE TABLE user_approval_role (
    id integer DEFAULT nextval('user_approval_role_id_seq'::regclass) NOT NULL,
    user_id integer NOT NULL,
    role_id integer NOT NULL,
    assigned_by_id integer,
    assigned_date timestamp without time zone,
    start_date timestamp without time zone,
    end_date timestamp without time zone,
    is_active boolean,
    notes text
);

INSERT INTO user_approval_role (id, user_id, role_id, assigned_by_id, assigned_date, start_date, end_date, is_active, notes) VALUES (1, 1, 1, 1, '2025-12-03T14:10:21.536234', '2025-12-03T14:10:21.536239', NULL, True, '系统自动分配');
INSERT INTO user_approval_role (id, user_id, role_id, assigned_by_id, assigned_date, start_date, end_date, is_active, notes) VALUES (2, 2, 2, 1, '2025-12-03T16:27:37.013965', '2025-12-03T16:27:37.013975', NULL, True, '');
INSERT INTO user_approval_role (id, user_id, role_id, assigned_by_id, assigned_date, start_date, end_date, is_active, notes) VALUES (3, 3, 3, 1, '2025-12-04T17:21:14.209674', '2025-12-04T00:00:00', '2025-12-05T00:00:00', True, '');


-- Table: user_custom_role
DROP TABLE IF EXISTS user_custom_role CASCADE;
CREATE TABLE user_custom_role (
    user_id integer NOT NULL,
    role_id integer NOT NULL,
    assigned_by_id integer,
    assigned_date timestamp without time zone,
    expired_date timestamp without time zone,
    is_active boolean,
    notes character varying(500)
);

INSERT INTO user_custom_role (user_id, role_id, assigned_by_id, assigned_date, expired_date, is_active, notes) VALUES (2, 1, 1, '2025-12-03T16:02:31.394612', NULL, True, NULL);


-- Table: workflow_instance
DROP TABLE IF EXISTS workflow_instance CASCADE;
CREATE TABLE workflow_instance (
    id integer DEFAULT nextval('workflow_instance_id_seq'::regclass) NOT NULL,
    template_id integer,
    order_type character varying(64) NOT NULL,
    order_id integer NOT NULL,
    current_node_id integer,
    status character varying(32),
    started_at timestamp without time zone,
    finished_at timestamp without time zone
);


-- Table: workflow_node
DROP TABLE IF EXISTS workflow_node CASCADE;
CREATE TABLE workflow_node (
    id integer DEFAULT nextval('workflow_node_id_seq'::regclass) NOT NULL,
    template_id integer NOT NULL,
    code character varying(64) NOT NULL,
    name character varying(128) NOT NULL,
    sequence integer NOT NULL,
    node_type character varying(32),
    approval_role_id integer,
    condition_expr text,
    amount_threshold numeric,
    skip_if_below_threshold boolean,
    is_parallel boolean,
    required_approvals integer,
    parallel_mode character varying(32),
    timeout_hours integer,
    timeout_action character varying(32),
    escalate_to_role_id integer,
    auto_approve_rules json,
    auto_reject_rules json,
    notify_on_start boolean,
    notify_on_complete boolean,
    notify_methods json,
    is_active boolean,
    approver_user_id integer,
    approver_user_ids text
);

INSERT INTO workflow_node (id, template_id, code, name, sequence, node_type, approval_role_id, condition_expr, amount_threshold, skip_if_below_threshold, is_parallel, required_approvals, parallel_mode, timeout_hours, timeout_action, escalate_to_role_id, auto_approve_rules, auto_reject_rules, notify_on_start, notify_on_complete, notify_methods, is_active, approver_user_id, approver_user_ids) VALUES (5, 6, 'part_request_order_node_1', '部门负责人审批', 1, 'approval', NULL, NULL, NULL, False, False, 1, NULL, NULL, NULL, NULL, NULL, NULL, True, True, NULL, True, NULL, NULL);
INSERT INTO workflow_node (id, template_id, code, name, sequence, node_type, approval_role_id, condition_expr, amount_threshold, skip_if_below_threshold, is_parallel, required_approvals, parallel_mode, timeout_hours, timeout_action, escalate_to_role_id, auto_approve_rules, auto_reject_rules, notify_on_start, notify_on_complete, notify_methods, is_active, approver_user_id, approver_user_ids) VALUES (6, 6, 'part_request_order_node_2', '管理员审批', 2, 'approval', NULL, NULL, '1000.00', True, False, 1, NULL, NULL, NULL, NULL, NULL, NULL, True, True, NULL, True, NULL, NULL);
INSERT INTO workflow_node (id, template_id, code, name, sequence, node_type, approval_role_id, condition_expr, amount_threshold, skip_if_below_threshold, is_parallel, required_approvals, parallel_mode, timeout_hours, timeout_action, escalate_to_role_id, auto_approve_rules, auto_reject_rules, notify_on_start, notify_on_complete, notify_methods, is_active, approver_user_id, approver_user_ids) VALUES (8, 7, 'equipment_transfer_node_1', '调出部门负责人审批', 1, 'approval', NULL, NULL, NULL, False, False, 1, NULL, NULL, NULL, NULL, NULL, NULL, True, True, NULL, True, NULL, NULL);
INSERT INTO workflow_node (id, template_id, code, name, sequence, node_type, approval_role_id, condition_expr, amount_threshold, skip_if_below_threshold, is_parallel, required_approvals, parallel_mode, timeout_hours, timeout_action, escalate_to_role_id, auto_approve_rules, auto_reject_rules, notify_on_start, notify_on_complete, notify_methods, is_active, approver_user_id, approver_user_ids) VALUES (9, 7, 'equipment_transfer_node_2', '管理员审批', 2, 'approval', NULL, NULL, NULL, False, False, 1, NULL, NULL, NULL, NULL, NULL, NULL, True, True, NULL, True, NULL, NULL);
INSERT INTO workflow_node (id, template_id, code, name, sequence, node_type, approval_role_id, condition_expr, amount_threshold, skip_if_below_threshold, is_parallel, required_approvals, parallel_mode, timeout_hours, timeout_action, escalate_to_role_id, auto_approve_rules, auto_reject_rules, notify_on_start, notify_on_complete, notify_methods, is_active, approver_user_id, approver_user_ids) VALUES (10, 7, 'equipment_transfer_node_3', '调入部门负责人确认', 3, 'approval', NULL, NULL, NULL, False, False, 1, NULL, NULL, NULL, NULL, NULL, NULL, True, True, NULL, True, NULL, NULL);
INSERT INTO workflow_node (id, template_id, code, name, sequence, node_type, approval_role_id, condition_expr, amount_threshold, skip_if_below_threshold, is_parallel, required_approvals, parallel_mode, timeout_hours, timeout_action, escalate_to_role_id, auto_approve_rules, auto_reject_rules, notify_on_start, notify_on_complete, notify_methods, is_active, approver_user_id, approver_user_ids) VALUES (11, 8, 'equipment_scrap_node_1', '部门负责人审批', 1, 'approval', NULL, NULL, NULL, False, False, 1, NULL, NULL, NULL, NULL, NULL, NULL, True, True, NULL, True, NULL, NULL);
INSERT INTO workflow_node (id, template_id, code, name, sequence, node_type, approval_role_id, condition_expr, amount_threshold, skip_if_below_threshold, is_parallel, required_approvals, parallel_mode, timeout_hours, timeout_action, escalate_to_role_id, auto_approve_rules, auto_reject_rules, notify_on_start, notify_on_complete, notify_methods, is_active, approver_user_id, approver_user_ids) VALUES (12, 8, 'equipment_scrap_node_2', '管理员审批', 2, 'approval', NULL, NULL, NULL, False, False, 1, NULL, NULL, NULL, NULL, NULL, NULL, True, True, NULL, True, NULL, NULL);
INSERT INTO workflow_node (id, template_id, code, name, sequence, node_type, approval_role_id, condition_expr, amount_threshold, skip_if_below_threshold, is_parallel, required_approvals, parallel_mode, timeout_hours, timeout_action, escalate_to_role_id, auto_approve_rules, auto_reject_rules, notify_on_start, notify_on_complete, notify_methods, is_active, approver_user_id, approver_user_ids) VALUES (13, 8, 'equipment_scrap_node_3', '财务审批', 3, 'approval', NULL, NULL, '10000.00', True, False, 1, NULL, NULL, NULL, NULL, NULL, NULL, True, True, NULL, True, NULL, NULL);
INSERT INTO workflow_node (id, template_id, code, name, sequence, node_type, approval_role_id, condition_expr, amount_threshold, skip_if_below_threshold, is_parallel, required_approvals, parallel_mode, timeout_hours, timeout_action, escalate_to_role_id, auto_approve_rules, auto_reject_rules, notify_on_start, notify_on_complete, notify_methods, is_active, approver_user_id, approver_user_ids) VALUES (14, 9, 'equipment_loan_node_1', '设备所属部门负责人审批', 1, 'approval', NULL, NULL, NULL, False, False, 1, NULL, NULL, NULL, NULL, NULL, NULL, True, True, NULL, True, NULL, NULL);
INSERT INTO workflow_node (id, template_id, code, name, sequence, node_type, approval_role_id, condition_expr, amount_threshold, skip_if_below_threshold, is_parallel, required_approvals, parallel_mode, timeout_hours, timeout_action, escalate_to_role_id, auto_approve_rules, auto_reject_rules, notify_on_start, notify_on_complete, notify_methods, is_active, approver_user_id, approver_user_ids) VALUES (15, 9, 'equipment_loan_node_2', '管理员审批', 2, 'approval', NULL, NULL, NULL, False, False, 1, NULL, NULL, NULL, NULL, NULL, NULL, True, True, NULL, True, NULL, NULL);
INSERT INTO workflow_node (id, template_id, code, name, sequence, node_type, approval_role_id, condition_expr, amount_threshold, skip_if_below_threshold, is_parallel, required_approvals, parallel_mode, timeout_hours, timeout_action, escalate_to_role_id, auto_approve_rules, auto_reject_rules, notify_on_start, notify_on_complete, notify_methods, is_active, approver_user_id, approver_user_ids) VALUES (7, 6, 'part_request_order_node_3', '仓库管理员发货', 3, 'approval', 4, NULL, NULL, False, False, 1, NULL, NULL, NULL, NULL, NULL, NULL, True, True, NULL, True, NULL, NULL);
INSERT INTO workflow_node (id, template_id, code, name, sequence, node_type, approval_role_id, condition_expr, amount_threshold, skip_if_below_threshold, is_parallel, required_approvals, parallel_mode, timeout_hours, timeout_action, escalate_to_role_id, auto_approve_rules, auto_reject_rules, notify_on_start, notify_on_complete, notify_methods, is_active, approver_user_id, approver_user_ids) VALUES (17, 10, 'equipment_application_node_2', '管理员审批', 2, 'approval', 1, NULL, NULL, False, False, 1, NULL, NULL, NULL, NULL, NULL, NULL, True, True, NULL, True, NULL, NULL);
INSERT INTO workflow_node (id, template_id, code, name, sequence, node_type, approval_role_id, condition_expr, amount_threshold, skip_if_below_threshold, is_parallel, required_approvals, parallel_mode, timeout_hours, timeout_action, escalate_to_role_id, auto_approve_rules, auto_reject_rules, notify_on_start, notify_on_complete, notify_methods, is_active, approver_user_id, approver_user_ids) VALUES (16, 10, 'equipment_application_node_1', '部门负责人审批', 1, 'approval', 2, NULL, NULL, False, False, 1, NULL, NULL, NULL, NULL, NULL, NULL, True, True, NULL, True, NULL, NULL);
INSERT INTO workflow_node (id, template_id, code, name, sequence, node_type, approval_role_id, condition_expr, amount_threshold, skip_if_below_threshold, is_parallel, required_approvals, parallel_mode, timeout_hours, timeout_action, escalate_to_role_id, auto_approve_rules, auto_reject_rules, notify_on_start, notify_on_complete, notify_methods, is_active, approver_user_id, approver_user_ids) VALUES (18, 10, 'equipment_application_node_3', '资产管理员分配', 3, 'execution', 4, NULL, NULL, False, False, 1, NULL, NULL, NULL, NULL, NULL, NULL, True, True, NULL, True, NULL, NULL);
INSERT INTO workflow_node (id, template_id, code, name, sequence, node_type, approval_role_id, condition_expr, amount_threshold, skip_if_below_threshold, is_parallel, required_approvals, parallel_mode, timeout_hours, timeout_action, escalate_to_role_id, auto_approve_rules, auto_reject_rules, notify_on_start, notify_on_complete, notify_methods, is_active, approver_user_id, approver_user_ids) VALUES (1, 5, 'repair_order_node_1', '部门负责人初审', 1, 'approval', 2, NULL, NULL, False, False, 1, NULL, NULL, NULL, NULL, NULL, NULL, True, True, NULL, True, NULL, NULL);
INSERT INTO workflow_node (id, template_id, code, name, sequence, node_type, approval_role_id, condition_expr, amount_threshold, skip_if_below_threshold, is_parallel, required_approvals, parallel_mode, timeout_hours, timeout_action, escalate_to_role_id, auto_approve_rules, auto_reject_rules, notify_on_start, notify_on_complete, notify_methods, is_active, approver_user_id, approver_user_ids) VALUES (2, 5, 'repair_order_node_2', '管理员评估金额', 2, 'approval', 1, NULL, NULL, False, False, 1, NULL, NULL, NULL, NULL, NULL, NULL, True, True, NULL, True, NULL, NULL);
INSERT INTO workflow_node (id, template_id, code, name, sequence, node_type, approval_role_id, condition_expr, amount_threshold, skip_if_below_threshold, is_parallel, required_approvals, parallel_mode, timeout_hours, timeout_action, escalate_to_role_id, auto_approve_rules, auto_reject_rules, notify_on_start, notify_on_complete, notify_methods, is_active, approver_user_id, approver_user_ids) VALUES (19, 5, 'pass', '系统管理员审核通过', 4, 'approval', 1, NULL, NULL, False, False, 1, NULL, NULL, NULL, NULL, NULL, NULL, True, True, NULL, True, NULL, NULL);
INSERT INTO workflow_node (id, template_id, code, name, sequence, node_type, approval_role_id, condition_expr, amount_threshold, skip_if_below_threshold, is_parallel, required_approvals, parallel_mode, timeout_hours, timeout_action, escalate_to_role_id, auto_approve_rules, auto_reject_rules, notify_on_start, notify_on_complete, notify_methods, is_active, approver_user_id, approver_user_ids) VALUES (3, 5, 'repair_order_node_3', '部门负责人确认金额', 3, 'approval', 2, NULL, '5000.00', False, False, 1, NULL, NULL, NULL, NULL, NULL, NULL, True, True, NULL, True, NULL, NULL);


-- Table: workflow_template
DROP TABLE IF EXISTS workflow_template CASCADE;
CREATE TABLE workflow_template (
    id integer DEFAULT nextval('workflow_template_id_seq'::regclass) NOT NULL,
    code character varying(64) NOT NULL,
    name character varying(128) NOT NULL,
    order_type character varying(64) NOT NULL,
    version integer,
    is_active boolean,
    is_default boolean,
    description text,
    config json,
    created_by_id integer,
    created_date timestamp without time zone,
    updated_date timestamp without time zone
);

INSERT INTO workflow_template (id, code, name, order_type, version, is_active, is_default, description, config, created_by_id, created_date, updated_date) VALUES (6, 'part_request_std_v1', '配件申请标准流程', 'part_request_order', 1, True, True, NULL, NULL, NULL, '2025-12-03T06:10:42.956599', NULL);
INSERT INTO workflow_template (id, code, name, order_type, version, is_active, is_default, description, config, created_by_id, created_date, updated_date) VALUES (7, 'equipment_transfer_std_v1', '设备调拨标准流程', 'equipment_transfer', 1, True, True, NULL, NULL, NULL, '2025-12-03T06:10:42.958364', NULL);
INSERT INTO workflow_template (id, code, name, order_type, version, is_active, is_default, description, config, created_by_id, created_date, updated_date) VALUES (8, 'equipment_scrap_std_v1', '设备报废标准流程', 'equipment_scrap', 1, True, True, NULL, NULL, NULL, '2025-12-03T06:10:42.960454', NULL);
INSERT INTO workflow_template (id, code, name, order_type, version, is_active, is_default, description, config, created_by_id, created_date, updated_date) VALUES (9, 'equipment_loan_std_v1', '设备借用标准流程', 'equipment_loan', 1, True, True, NULL, NULL, NULL, '2025-12-03T06:10:42.962831', NULL);
INSERT INTO workflow_template (id, code, name, order_type, version, is_active, is_default, description, config, created_by_id, created_date, updated_date) VALUES (10, 'equipment_application_std_v1', '设备申请标准流程', 'equipment_application', 1, True, True, NULL, NULL, NULL, '2025-12-03T06:10:42.965220', NULL);
INSERT INTO workflow_template (id, code, name, order_type, version, is_active, is_default, description, config, created_by_id, created_date, updated_date) VALUES (5, 'repair_order_std_v1', '维修工单标准流程', 'repair_order', 1, True, True, '', NULL, NULL, '2025-12-03T06:10:42.953728', '2025-12-05T14:23:00.142048');

