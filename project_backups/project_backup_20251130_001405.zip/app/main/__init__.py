from flask import Blueprint

bp = Blueprint('main', __name__)

from app.main import routes
from app.main import asset_routes  # 统一资产/配件管理中心
from app.main import cost_routes   # 成本分析
from app.main import inventory_routes  # 库存预警
from app.main import lifecycle_routes  # 生命周期管理
from app.main import workflow_routes  # 审批流程模板管理