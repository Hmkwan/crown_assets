from datetime import datetime
from flask_sqlalchemy import SQLAlchemy
from flask_login import UserMixin
from werkzeug.security import generate_password_hash, check_password_hash
from app import db, get_beijing_now


class User(UserMixin, db.Model):
    id = db.Column(db.Integer, primary_key=True)
    username = db.Column(db.String(64), index=True, unique=True)
    email = db.Column(db.String(120), index=True, unique=True)
    password_hash = db.Column(db.String(128))
    role = db.Column(db.String(64), default='user')  # 'admin', 'user', 'technician', 'department_head'
    department_id = db.Column(db.Integer, db.ForeignKey('department.id'))
    department = db.Column(db.String(120))
    is_active = db.Column(db.Boolean, default=True)  # 用户是否活跃（用于选择审批人时过滤）
    
    # 审批流角色（可多选，JSON格式存储）
    # 例如: '["department_head", "procurement"]' 表示该用户既是部门经理又是采购
    workflow_roles = db.Column(db.Text, nullable=True)  # JSON array of roles
    
    # 用户模块权限
    can_manage_equipment = db.Column(db.Boolean, default=False)
    can_manage_spare_parts = db.Column(db.Boolean, default=False)
    can_manage_repairs = db.Column(db.Boolean, default=False)
    can_manage_part_requests = db.Column(db.Boolean, default=False)
    can_view_workflow = db.Column(db.Boolean, default=False)
    can_edit_workflow = db.Column(db.Boolean, default=False)  # 编辑/创建工作流节点
    can_manage_workflow_templates = db.Column(db.Boolean, default=False)  # 管理工作流模板
    can_view_reports = db.Column(db.Boolean, default=False)
    can_view_logs = db.Column(db.Boolean, default=False)
    
    def set_password(self, password):
        self.password_hash = generate_password_hash(password)
        
    def check_password(self, password):
        return check_password_hash(self.password_hash, password)
        
    def is_admin(self):
        return self.role == 'admin'
        
    def is_department_head(self):
        return self.role == 'department_head'

    def get_department_name(self):
        """返回用户所属部门的显示名称。
        优先返回关联的 Department 对象的 name 字段，若不存在则回退到 `department` 文本字段，最后返回空字符串。
        这样可以避免模板中直接调用未定义方法导致的错误。
        """
        try:
            if hasattr(self, 'dept') and self.dept:
                return getattr(self.dept, 'name', '') or ''
            return self.department or ''
        except Exception:
            return ''

    def get_role_display(self):
        """将内部 role 值映射为中文显示文本。"""
        mapping = {
            'admin': '管理员',
            'user': '普通用户',
            'technician': '技术员',
            'department_head': '部门主管'
        }
        return mapping.get(self.role, self.role or '')
    
    def get_workflow_roles(self):
        """获取用户的审批流角色列表"""
        if not self.workflow_roles:
            # 如果没有设置workflow_roles，根据role字段自动映射
            role_mapping = {
                'admin': ['admin'],
                'department_head': ['department_head'],
                'technician': ['admin'],  # 技术员默认有IT管理员权限
            }
            return role_mapping.get(self.role, ['employee'])
        
        try:
            import json
            roles = json.loads(self.workflow_roles)
            return roles if isinstance(roles, list) else []
        except Exception:
            return []
    
    def has_workflow_role(self, role):
        """检查用户是否拥有指定的审批流角色"""
        return role in self.get_workflow_roles()
    
    def set_workflow_roles(self, roles):
        """设置用户的审批流角色"""
        import json
        if isinstance(roles, list):
            self.workflow_roles = json.dumps(roles)
        else:
            self.workflow_roles = None
    
    def get_workflow_roles_display(self):
        """获取审批流角色的中文显示"""
        role_display_mapping = {
            'employee': '员工',
            'department_head': '部门经理',
            'admin': '系统管理员',
            'procurement': '采购',
            'warehouse': '库房',
            'security': '安全/合规',
            'finance': '财务',
            'executive': '总经理/高层',
            'auditor': '审计/稽核'
        }
        roles = self.get_workflow_roles()
        return ', '.join([role_display_mapping.get(r, r) for r in roles])
        
    def has_module_access(self, module):
        """检查用户是否具有特定模块的访问权限"""
        if self.is_admin():
            return True
            
        module_permissions = {
            'equipment': self.can_manage_equipment,
            'spare_parts': self.can_manage_spare_parts,
            'repairs': self.can_manage_repairs,
            'part_requests': self.can_manage_part_requests,
            'workflow': getattr(self, 'can_view_workflow', False),
            'workflow_edit': getattr(self, 'can_edit_workflow', False),
            'workflow_templates': getattr(self, 'can_manage_workflow_templates', False),
            'reports': getattr(self, 'can_view_reports', False),
            'logs': getattr(self, 'can_view_logs', False)
        }
        
        return module_permissions.get(module, False)
    
    def has_permission(self, module, action, context=None):
        """
        检查用户是否具有特定的模块+操作权限（细粒度控制）
        
        Args:
            module: 模块名（如'equipment', 'repair'）
            action: 操作名（如'view', 'create', 'edit', 'delete', 'approve'）
            context: 上下文条件字典（如{'department_id': 1, 'amount': 5000}）
        
        Returns:
            bool: 是否有权限
        """
        if self.is_admin():
            return True
        
        context = context or {}
        
        # 先检查传统权限标志
        if self.has_module_access(module):
            return True
        
        # 检查自定义角色权限
        try:
            from app.models import Permission
            perms = Permission.query.filter_by(is_granted=True).all()
            
            for perm in perms:
                # 检查角色是否与用户关联
                if perm.role in self.custom_roles:
                    if perm.module == module and perm.action == action:
                        if perm.check_condition(context):
                            return True
        except:
            pass
        
        return False
    
    def get_all_permissions(self):
        """获取用户的所有权限（模块+操作）"""
        if self.is_admin():
            return {
                'equipment': ['view', 'create', 'edit', 'delete'],
                'repair': ['view', 'create', 'edit', 'approve', 'complete'],
                'loan': ['view', 'create', 'approve', 'return'],
                'transfer': ['view', 'create', 'approve'],
                'scrap': ['view', 'create', 'approve'],
                'report': ['view', 'export'],
            }
        
        perms = {}
        try:
            from app.models import Permission
            for role in self.custom_roles:
                for perm in role.permissions:
                    if perm.is_granted:
                        if perm.module not in perms:
                            perms[perm.module] = []
                        perms[perm.module].append(perm.action)
        except:
            pass
        
        return perms
        
    def __repr__(self):
        return f'<User {self.username}>'


class Equipment(db.Model):
    id = db.Column(db.Integer, primary_key=True)
    name = db.Column(db.String(120), index=True)
    type_id = db.Column(db.Integer, db.ForeignKey('equipment_type.id'))  # 添加设备类型外键
    type = db.Column(db.String(64))  # 保留原有type字段以兼容旧数据
    brand = db.Column(db.String(64))
    model = db.Column(db.String(64))
    serial_number = db.Column(db.String(120), unique=True)
    purchase_date = db.Column(db.Date)
    price = db.Column(db.Float, default=0.0)  # 设备金额，用于成本分析
    department_id = db.Column(db.Integer, db.ForeignKey('department.id'))
    department = db.Column(db.String(120))
    status = db.Column(db.String(64), default='active')  # active, repair, retired, available
    is_public_pool = db.Column(db.Boolean, default=False)
    
    # 关联设备类型
    equipment_type = db.relationship('EquipmentType', backref='equipments')
    
    def __repr__(self):
        return f'<Equipment {self.name}>'


class RepairOrder(db.Model):
    id = db.Column(db.Integer, primary_key=True)
    equipment_id = db.Column(db.Integer, db.ForeignKey('equipment.id'))
    requester_id = db.Column(db.Integer, db.ForeignKey('user.id'))
    technician_id = db.Column(db.Integer, db.ForeignKey('user.id'))
    department_head_id = db.Column(db.Integer, db.ForeignKey('user.id'))  # 部门领导审批人
    admin_id = db.Column(db.Integer, db.ForeignKey('user.id'))  # 管理员审批人
    
    description = db.Column(db.Text)
    status = db.Column(db.String(64), default='submitted')  # submitted, department_head_approved, admin_approved, in_progress, completed, cancelled
    
    # 时间字段
    created_date = db.Column(db.DateTime, default=get_beijing_now)
    updated_date = db.Column(db.DateTime, default=get_beijing_now, onupdate=get_beijing_now)
    completed_date = db.Column(db.DateTime)
    
    # 审批状态
    department_head_approved = db.Column(db.Boolean, default=False)
    admin_approved = db.Column(db.Boolean, default=False)
    
    # 关联关系
    equipment = db.relationship('Equipment', backref='repair_orders')
    requester = db.relationship('User', foreign_keys=[requester_id], backref='requested_orders')
    technician = db.relationship('User', foreign_keys=[technician_id], backref='assigned_orders')
    department_head = db.relationship('User', foreign_keys=[department_head_id], backref='department_head_approved_orders')
    admin = db.relationship('User', foreign_keys=[admin_id], backref='admin_approved_orders')
    
    def __repr__(self):
        return f'<RepairOrder {self.id}>'


class SparePart(db.Model):
    id = db.Column(db.Integer, primary_key=True)
    name = db.Column(db.String(120), index=True)
    part_number = db.Column(db.String(120), unique=True)
    type_id = db.Column(db.Integer, db.ForeignKey('spare_part_type.id'))  # 配件类型ID
    price = db.Column(db.Float)
    stock_quantity = db.Column(db.Integer, default=0)
    min_stock_level = db.Column(db.Integer, default=10)
    department_id = db.Column(db.Integer, db.ForeignKey('department.id'))
    department = db.Column(db.String(120))
    location = db.Column(db.String(120))
    purchase_date = db.Column(db.Date)
    is_public = db.Column(db.Boolean, default=False)  # 是否公开到仓库
    
    # 关系
    spare_part_type = db.relationship('SparePartType', backref='spare_parts', foreign_keys=[type_id])
    
    def __repr__(self):
        return f'<SparePart {self.name}>'


class PartReplacement(db.Model):
    id = db.Column(db.Integer, primary_key=True)
    repair_order_id = db.Column(db.Integer, db.ForeignKey('repair_order.id'))
    spare_part_id = db.Column(db.Integer, db.ForeignKey('spare_part.id'))
    quantity = db.Column(db.Integer, default=1)
    replacement_date = db.Column(db.DateTime, default=get_beijing_now)
    
    # 关联关系
    repair_order = db.relationship('RepairOrder', backref='part_replacements')
    spare_part = db.relationship('SparePart', backref='part_replacements')
    
    def __repr__(self):
        return f'<PartReplacement {self.id}>'


class Department(db.Model):
    id = db.Column(db.Integer, primary_key=True)
    name = db.Column(db.String(120), unique=True)
    code = db.Column(db.String(64), unique=True)
    cost_center = db.Column(db.String(64))
    location = db.Column(db.String(120))
    description = db.Column(db.Text)
    
    users = db.relationship('User', backref='dept')
    equipment = db.relationship('Equipment', backref='dept')
    spare_parts = db.relationship('SparePart', backref='dept')
    
    def __repr__(self):
        return f'<Department {self.name}>'


class PartRequestOrder(db.Model):
    """配件申请订单"""
    id = db.Column(db.Integer, primary_key=True)
    requester_id = db.Column(db.Integer, db.ForeignKey('user.id'))
    department_head_id = db.Column(db.Integer, db.ForeignKey('user.id'))  # 部门领导审批人
    admin_id = db.Column(db.Integer, db.ForeignKey('user.id'))  # 管理员审批人
    
    part_name = db.Column(db.String(120))
    part_number = db.Column(db.String(120))
    quantity = db.Column(db.Integer, default=1)
    reason = db.Column(db.Text)
    
    status = db.Column(db.String(64), default='submitted')  # submitted, department_head_approved, admin_approved, completed, cancelled
    
    # 审批状态
    department_head_approved = db.Column(db.Boolean, default=False)
    admin_approved = db.Column(db.Boolean, default=False)
    
    created_date = db.Column(db.DateTime, default=get_beijing_now)
    updated_date = db.Column(db.DateTime, default=get_beijing_now, onupdate=get_beijing_now)
    completed_date = db.Column(db.DateTime)
    
    # 关联关系
    requester = db.relationship('User', foreign_keys=[requester_id], backref='requested_part_orders')
    department_head = db.relationship('User', foreign_keys=[department_head_id], backref='department_head_approved_part_orders')
    admin = db.relationship('User', foreign_keys=[admin_id], backref='admin_approved_part_orders')
    
    def __repr__(self):
        return f'<PartRequestOrder {self.id}>'


class AccountRequest(db.Model):
    __tablename__ = 'account_request'
    id = db.Column(db.Integer, primary_key=True)
    username = db.Column(db.String(64), index=True, unique=True)
    full_name = db.Column(db.String(120))
    employee_no = db.Column(db.String(64))
    email = db.Column(db.String(120))
    department = db.Column(db.String(120))
    role_requested = db.Column(db.String(64), default='user')
    reason = db.Column(db.Text)
    password_hash = db.Column(db.String(128))
    status = db.Column(db.String(32), default='pending')  # pending, approved, rejected
    created_date = db.Column(db.DateTime, default=get_beijing_now)
    processed_date = db.Column(db.DateTime)
    approver_id = db.Column(db.Integer, db.ForeignKey('user.id'))
    approver_comments = db.Column(db.Text)
    
    approver = db.relationship('User', foreign_keys=[approver_id])
    
    def set_password(self, password):
        self.password_hash = generate_password_hash(password)
    
    def check_password(self, password):
        return check_password_hash(self.password_hash, password)
    
    def __repr__(self):
        return f'<AccountRequest {self.username}>'


class ApprovalWorkflow(db.Model):
    """审批流程"""
    id = db.Column(db.Integer, primary_key=True)
    order_type = db.Column(db.String(64))  # 'repair_order', 'part_request_order'
    order_id = db.Column(db.Integer)
    approver_id = db.Column(db.Integer, db.ForeignKey('user.id'))
    approval_level = db.Column(db.String(64))  # 'department_head', 'admin'
    node_id = db.Column(db.Integer, db.ForeignKey('workflow_node.id'))  # 添加节点ID关联
    status = db.Column(db.String(64), default='pending')  # 'pending', 'approved', 'rejected'
    comments = db.Column(db.Text)
    created_date = db.Column(db.DateTime, default=get_beijing_now)
    approved_date = db.Column(db.DateTime)
    auto_assigned = db.Column(db.Boolean, default=False)
    
    # 关联关系
    approver = db.relationship('User', backref='approvals')
    workflow_node = db.relationship('WorkflowNode', backref='approvals')  # 添加工作流节点关联
    
    def __repr__(self):
        return f'<ApprovalWorkflow {self.id}>'


class EquipmentTransfer(db.Model):
    """设备调拨申请"""
    id = db.Column(db.Integer, primary_key=True)
    equipment_id = db.Column(db.Integer, db.ForeignKey('equipment.id'))
    from_department = db.Column(db.String(120))
    to_department = db.Column(db.String(120))
    requester_id = db.Column(db.Integer, db.ForeignKey('user.id'))
    description = db.Column(db.Text)
    status = db.Column(db.String(64), default='submitted')
    created_date = db.Column(db.DateTime, default=get_beijing_now)
    updated_date = db.Column(db.DateTime, default=get_beijing_now, onupdate=get_beijing_now)

    equipment = db.relationship('Equipment', backref='transfer_orders')
    requester = db.relationship('User', foreign_keys=[requester_id], backref='transfer_requests')

    def __repr__(self):
        return f'<EquipmentTransfer {self.id}>'


class EquipmentScrap(db.Model):
    """设备报废申请"""
    id = db.Column(db.Integer, primary_key=True)
    equipment_id = db.Column(db.Integer, db.ForeignKey('equipment.id'))
    requester_id = db.Column(db.Integer, db.ForeignKey('user.id'))
    description = db.Column(db.Text)
    status = db.Column(db.String(64), default='submitted')
    created_date = db.Column(db.DateTime, default=get_beijing_now)
    updated_date = db.Column(db.DateTime, default=get_beijing_now, onupdate=get_beijing_now)

    equipment = db.relationship('Equipment', backref='scrap_requests')
    requester = db.relationship('User', foreign_keys=[requester_id], backref='scrap_requests')

    def __repr__(self):
        return f'<EquipmentScrap {self.id}>'


class EquipmentLoan(db.Model):
    """设备借用申请"""
    id = db.Column(db.Integer, primary_key=True)
    equipment_id = db.Column(db.Integer, db.ForeignKey('equipment.id'))
    requester_id = db.Column(db.Integer, db.ForeignKey('user.id'))
    requester_dept = db.Column(db.String(120))

    # 计划借用起止时间
    start_date = db.Column(db.DateTime)
    end_date = db.Column(db.DateTime)

    # 状态：submitted, approved, borrowed, returned, cancelled, rejected
    status = db.Column(db.String(64), default='submitted')

    # 审批/借出/归还记录
    approved_by = db.Column(db.Integer, db.ForeignKey('user.id'))
    approved_date = db.Column(db.DateTime)
    borrowed_date = db.Column(db.DateTime)
    returned_date = db.Column(db.DateTime)

    notes = db.Column(db.Text)
    pickup_notified = db.Column(db.Boolean, default=False)

    created_date = db.Column(db.DateTime, default=get_beijing_now)
    updated_date = db.Column(db.DateTime, default=get_beijing_now, onupdate=get_beijing_now)

    # 关联关系
    equipment = db.relationship('Equipment', backref='loan_requests')
    requester = db.relationship('User', foreign_keys=[requester_id], backref='loan_requests')
    approver = db.relationship('User', foreign_keys=[approved_by], backref='approved_loans')

    def __repr__(self):
        return f'<EquipmentLoan {self.id}>'


class EquipmentApplication(db.Model):
    id = db.Column(db.Integer, primary_key=True)
    equipment_id = db.Column(db.Integer, db.ForeignKey('equipment.id'))
    applicant_id = db.Column(db.Integer, db.ForeignKey('user.id'))
    applicant_dept = db.Column(db.String(120))
    reason = db.Column(db.Text)
    status = db.Column(db.String(64), default='submitted')  # submitted, approved, rejected, cancelled
    created_date = db.Column(db.DateTime, default=get_beijing_now)
    approved_date = db.Column(db.DateTime)

    equipment = db.relationship('Equipment', backref=db.backref('applications', cascade='all, delete-orphan'))
    applicant = db.relationship('User', foreign_keys=[applicant_id], backref='equipment_applications')

    def __repr__(self):
        return f'<EquipmentApplication {self.id}>'


class WorkflowNode(db.Model):
    """工作流节点"""
    id = db.Column(db.Integer, primary_key=True)
    template_id = db.Column(db.Integer, db.ForeignKey('workflow_template.id'), nullable=True)  # 新增：关联模板
    name = db.Column(db.String(120))
    order_type = db.Column(db.String(64))  # 'repair_order' 或 'part_request_order' (兼容旧版)
    node_type = db.Column(db.String(32), nullable=True)  # 新增：approval/condition/auto/notify/parallel/join
    role_required = db.Column(db.String(64))  # 所需角色: 'department_head', 'admin', 'technician'
    # 可选：指定具体的审批人用户ID，若指定则优先使用此用户而不是按角色查找
    approver_user_id = db.Column(db.Integer, db.ForeignKey('user.id'), nullable=True)
    # 可选：指定多个审批人（并行审批场景），以 JSON 字符串保存用户ID列表，例如: "[1,2,3]"
    approver_user_ids = db.Column(db.Text, nullable=True)
    sequence = db.Column(db.Integer)  # 执行顺序
    is_active = db.Column(db.Boolean, default=True)
    created_date = db.Column(db.DateTime, default=get_beijing_now)
    # 支持并行审批与拒绝时自动动作配置
    is_parallel = db.Column(db.Boolean, default=False)
    required_approvals = db.Column(db.Integer, default=1)
    actions_on_reject = db.Column(db.Text)  # JSON 字符串，example: '{"return_to": "requester"}'
    actions_on_approve = db.Column(db.Text, nullable=True)  # 新增：批准时的自动操作
    condition_expr = db.Column(db.Text, nullable=True)  # 新增：条件表达式（用于条件分支节点）
    timeout_seconds = db.Column(db.Integer, nullable=True)  # 新增：超时时间（秒）
    escalation_target = db.Column(db.String(128), nullable=True)  # 新增：升级目标（角色或用户ID）
    
    def get_approver_user(self):
        """获取指定的审批人用户"""
        if self.approver_user_id:
            return User.query.get(self.approver_user_id)
        return None

    def get_approver_users(self):
        """如果配置了多个审批人，返回 User 列表"""
        if not self.approver_user_ids:
            return []
        try:
            import json
            # 尝试JSON解析
            try:
                ids = json.loads(self.approver_user_ids)
                if isinstance(ids, list):
                    users = [User.query.get(int(i)) for i in ids if i]
                    return [u for u in users if u]
            except (json.JSONDecodeError, ValueError):
                pass
            
            # 如果JSON解析失败，尝试逗号分隔的字符串
            if isinstance(self.approver_user_ids, str):
                ids = [i.strip() for i in self.approver_user_ids.split(',') if i.strip()]
                users = [User.query.get(int(i)) for i in ids if i]
                return [u for u in users if u]
            
            return []
        except Exception as e:
            print(f"解析审批人ID失败: {e}")
            return []
    
    def __repr__(self):
        return f'<WorkflowNode {self.name}>'



class Notification(db.Model):
    """通知"""
    id = db.Column(db.Integer, primary_key=True)
    user_id = db.Column(db.Integer, db.ForeignKey('user.id'))
    title = db.Column(db.String(120))
    message = db.Column(db.Text)
    is_read = db.Column(db.Boolean, default=False)
    created_date = db.Column(db.DateTime, default=get_beijing_now)
    # 支持跳转到相关订单
    order_type = db.Column(db.String(64))  # repair_order, part_request_order, equipment_application, etc.
    order_id = db.Column(db.Integer)  # 相关订单ID
    
    user = db.relationship('User', backref='notifications')
    

class EquipmentType(db.Model):
    """设备类型"""
    id = db.Column(db.Integer, primary_key=True)
    name = db.Column(db.String(120), unique=True, nullable=False)
    description = db.Column(db.Text)
    created_date = db.Column(db.DateTime, default=get_beijing_now)
    
    def __repr__(self):
        return f'<EquipmentType {self.name}>'


class SparePartType(db.Model):
    """配件类型"""
    id = db.Column(db.Integer, primary_key=True)
    name = db.Column(db.String(120), unique=True, nullable=False)
    description = db.Column(db.Text)
    created_date = db.Column(db.DateTime, default=get_beijing_now)
    
    def __repr__(self):
        return f'<SparePartType {self.name}>'


class UserActivityLog(db.Model):
    """用户活动日志"""
    id = db.Column(db.Integer, primary_key=True)
    user_id = db.Column(db.Integer, db.ForeignKey('user.id'))
    action = db.Column(db.String(120))
    description = db.Column(db.Text)
    timestamp = db.Column(db.DateTime, default=get_beijing_now)
    
    user = db.relationship('User', backref='activity_logs')
    
    def __repr__(self):
        return f'<UserActivityLog {self.id}>'


class AssetCost(db.Model):
    """资产成本管理"""
    id = db.Column(db.Integer, primary_key=True)
    equipment_id = db.Column(db.Integer, db.ForeignKey('equipment.id'), unique=True)
    purchase_price = db.Column(db.Float, default=0)  # 采购价格
    purchase_date = db.Column(db.Date)  # 采购日期
    maintenance_cost = db.Column(db.Float, default=0)  # 维护成本
    depreciation_rate = db.Column(db.Float, default=0.2)  # 折旧率（20% 默认）
    residual_value = db.Column(db.Float)  # 残值
    depreciation_method = db.Column(db.String(64), default='straight_line')  # 折旧方法
    expected_lifespan = db.Column(db.Integer, default=5)  # 预期使用年限（年）
    supplier = db.Column(db.String(120))  # 供应商
    warranty_period = db.Column(db.Integer)  # 保修期（月）
    created_date = db.Column(db.DateTime, default=get_beijing_now)
    updated_date = db.Column(db.DateTime, default=get_beijing_now, onupdate=get_beijing_now)
    
    equipment = db.relationship('Equipment', backref='cost')
    
    def calculate_current_value(self):
        """计算当前价值（直线法折旧）"""
        if not self.purchase_price or not self.purchase_date:
            return 0
        
        months_used = (get_beijing_now().date() - self.purchase_date).days / 30
        total_months = self.expected_lifespan * 12
        
        if months_used >= total_months:
            return self.residual_value or 0
        
        depreciation_amount = (self.purchase_price - (self.residual_value or 0)) * (months_used / total_months)
        return self.purchase_price - depreciation_amount
    
    def calculate_total_cost(self):
        """计算总投入成本"""
        return self.purchase_price + self.maintenance_cost
    
    def __repr__(self):
        return f'<AssetCost {self.equipment_id}>'


class AssetLifecycle(db.Model):
    """资产生命周期事件记录"""
    id = db.Column(db.Integer, primary_key=True)
    equipment_id = db.Column(db.Integer, db.ForeignKey('equipment.id'))
    event_type = db.Column(db.String(64))  # purchase, deployment, maintenance, upgrade, retirement
    event_date = db.Column(db.DateTime, default=get_beijing_now)
    old_status = db.Column(db.String(64))  # 旧状态
    new_status = db.Column(db.String(64))  # 新状态
    description = db.Column(db.Text)
    responsible_user_id = db.Column(db.Integer, db.ForeignKey('user.id'))
    cost_involved = db.Column(db.Float, default=0)  # 相关成本
    documents = db.Column(db.Text)  # 相关文档/附件路径
    
    equipment = db.relationship('Equipment', backref='lifecycle_events')
    responsible_user = db.relationship('User', backref='lifecycle_events')
    
    def __repr__(self):
        return f'<AssetLifecycle {self.equipment_id}>'


class InventoryWarning(db.Model):
    """库存预警规则"""
    id = db.Column(db.Integer, primary_key=True)
    spare_part_id = db.Column(db.Integer, db.ForeignKey('spare_part.id'))
    min_threshold = db.Column(db.Integer)  # 最小库存
    critical_threshold = db.Column(db.Integer)  # 紧急库存
    reorder_quantity = db.Column(db.Integer)  # 建议采购数量
    lead_time_days = db.Column(db.Integer, default=7)  # 采购周期（天）
    enabled = db.Column(db.Boolean, default=True)
    last_warned_date = db.Column(db.DateTime)  # 上次预警时间
    created_date = db.Column(db.DateTime, default=get_beijing_now)
    
    spare_part = db.relationship('SparePart', backref='warning_rule')
    
    def is_critical(self):
        """是否处于紧急状态"""
        return self.spare_part.stock_quantity <= self.critical_threshold if self.spare_part else False
    
    def is_warning(self):
        """是否处于预警状态"""
        return self.spare_part.stock_quantity <= self.min_threshold if self.spare_part else False
    
    def __repr__(self):
        return f'<InventoryWarning {self.spare_part_id}>'


class AssetHandover(db.Model):
    """资产交接单（员工离职/转岗）"""
    id = db.Column(db.Integer, primary_key=True)
    from_user_id = db.Column(db.Integer, db.ForeignKey('user.id'))
    to_user_id = db.Column(db.Integer, db.ForeignKey('user.id'), nullable=True)
    equipment_ids = db.Column(db.Text)  # JSON 格式存储
    status = db.Column(db.String(64), default='pending')  # pending, in_progress, completed, cancelled
    reason = db.Column(db.String(64))  # resignation, transfer, other
    reason_detail = db.Column(db.Text)
    created_date = db.Column(db.DateTime, default=get_beijing_now)
    completed_date = db.Column(db.DateTime)
    completed_by_id = db.Column(db.Integer, db.ForeignKey('user.id'))
    
    # 关联关系
    from_user = db.relationship('User', foreign_keys=[from_user_id], backref='handover_from')
    to_user = db.relationship('User', foreign_keys=[to_user_id], backref='handover_to')
    completed_by = db.relationship('User', foreign_keys=[completed_by_id], backref='completed_handovers')
    

class RoleDefinition(db.Model):
    """自定义角色定义（支持细粒度权限）"""
    id = db.Column(db.Integer, primary_key=True)
    name = db.Column(db.String(64), unique=True)  # 角色名称
    description = db.Column(db.Text)  # 角色描述
    is_custom = db.Column(db.Boolean, default=True)  # 是否自定义（False为系统内置）
    is_active = db.Column(db.Boolean, default=True)
    created_date = db.Column(db.DateTime, default=get_beijing_now)
    created_by_id = db.Column(db.Integer, db.ForeignKey('user.id'))
    
    permissions = db.relationship('Permission', backref='role_def', cascade='all, delete-orphan')
    users = db.relationship('User', secondary='user_custom_role', backref='custom_roles')
    
    def __repr__(self):
        return f'<RoleDefinition {self.name}>'


class Permission(db.Model):
    """权限定义（模块+操作级别）"""
    id = db.Column(db.Integer, primary_key=True)
    role_id = db.Column(db.Integer, db.ForeignKey('role_definition.id'))
    module = db.Column(db.String(64))  # 模块：equipment, repair, loan, transfer, scrap, report等
    action = db.Column(db.String(64))  # 操作：view, create, edit, delete, approve等
    resource_type = db.Column(db.String(64), nullable=True)  # 资源类型
    conditions = db.Column(db.Text)  # JSON格式条件，如{"department_id": [1, 2, 3]}
    is_granted = db.Column(db.Boolean, default=True)  # True表示授权，False表示禁用
    priority = db.Column(db.Integer, default=0)  # 优先级，处理冲突时用
    created_date = db.Column(db.DateTime, default=get_beijing_now)
    
    def check_condition(self, context):
        """检查权限条件是否满足"""
        if not self.conditions:
            return True
        try:
            import json
            cond = json.loads(self.conditions)
            # 简单检查示例
            for key, value in cond.items():
                if key in context and context[key] not in value:
                    return False
            return True
        except:
            return True
    
    def __repr__(self):
        return f'<Permission {self.module}.{self.action}>'


# 多对多关联表
user_custom_role = db.Table('user_custom_role',
    db.Column('user_id', db.Integer, db.ForeignKey('user.id'), primary_key=True),
    db.Column('role_id', db.Integer, db.ForeignKey('role_definition.id'), primary_key=True)
)


class AuditLog(db.Model):
    """审计日志 - 记录所有权限操作"""
    id = db.Column(db.Integer, primary_key=True)
    user_id = db.Column(db.Integer, db.ForeignKey('user.id'))
    action_type = db.Column(db.String(64))  # create, update, delete, approve, deny等
    resource_type = db.Column(db.String(64))  # equipment, repair_order等
    resource_id = db.Column(db.Integer)
    old_value = db.Column(db.Text)  # 修改前值
    new_value = db.Column(db.Text)  # 修改后值
    ip_address = db.Column(db.String(64))
    reason = db.Column(db.Text)  # 操作原因
    created_date = db.Column(db.DateTime, default=get_beijing_now)
    
    user = db.relationship('User', backref='audit_logs')
    
    def __repr__(self):
        return f'<AuditLog {self.action_type} {self.resource_type}#{self.resource_id}>'
    

class WorkflowTemplate(db.Model):
    """审批流程模板（可配置，支持多场景）"""
    id = db.Column(db.Integer, primary_key=True)
    name = db.Column(db.String(120))  # 模板名称
    order_type = db.Column(db.String(64))  # 订单类型
    description = db.Column(db.Text)
    is_active = db.Column(db.Boolean, default=True)
    # 是否为系统默认流程（管理员可一键设置）
    is_default = db.Column(db.Boolean, default=False)
    created_by_id = db.Column(db.Integer, db.ForeignKey('user.id'))
    created_date = db.Column(db.DateTime, default=get_beijing_now)
    updated_date = db.Column(db.DateTime, default=get_beijing_now, onupdate=get_beijing_now)
    
    steps = db.relationship('WorkflowStep', backref='template', cascade='all, delete-orphan')
    # 添加nodes关系，关联WorkflowNode
    nodes = db.relationship('WorkflowNode', backref='template', foreign_keys='WorkflowNode.template_id', 
                          lazy='dynamic', cascade='all, delete-orphan')
    
    def __repr__(self):
        return f'<WorkflowTemplate {self.name}>'


class WorkflowStep(db.Model):
    """审批流程步骤"""
    id = db.Column(db.Integer, primary_key=True)
    template_id = db.Column(db.Integer, db.ForeignKey('workflow_template.id'))
    sequence = db.Column(db.Integer)  # 执行顺序
    step_name = db.Column(db.String(120))  # 步骤名称
    approver_role = db.Column(db.String(64))  # 审批人角色
    approver_dept = db.Column(db.String(120), nullable=True)  # 特定部门（可选）
    is_parallel = db.Column(db.Boolean, default=False)  # 是否并行审批
    timeout_days = db.Column(db.Integer, default=5)  # 审批超时时间（天）
    required_approvals = db.Column(db.Integer, default=1)  # 并行审批时需要的最少同意人数
    conditions = db.Column(db.Text)  # JSON条件：{"amount_gt": 10000, "type": "repair"}
    actions_on_approve = db.Column(db.Text)  # 批准时的自动操作
    actions_on_reject = db.Column(db.Text)  # 拒绝时的自动操作
    
    def __repr__(self):
        return f'<WorkflowStep {self.step_name}>'
