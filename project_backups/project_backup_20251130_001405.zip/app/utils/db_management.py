"""
数据库管理工具模块
提供数据库备份、恢复、重置等功能
"""
import os
import shutil
from datetime import datetime, timedelta, timezone
import subprocess
import shlex
import sys
try:
    import pytz
except Exception:
    pytz = None
try:
    from zoneinfo import ZoneInfo
except Exception:
    ZoneInfo = None


def get_backup_dir():
    """获取备份目录路径"""
    PROJECT_ROOT = os.path.abspath(os.path.join(os.path.dirname(__file__), '..', '..'))
    backup_dir = os.path.join(PROJECT_ROOT, 'backups')
    os.makedirs(backup_dir, exist_ok=True)
    return backup_dir


def backup_database():
    """备份数据库"""
    try:
        from flask import has_app_context, current_app
        if not has_app_context():
            return {'success': False, 'message': '需要在应用上下文中执行'}
        db_uri = current_app.config['SQLALCHEMY_DATABASE_URI']
        
        # SQLite 数据库路径
        if db_uri.startswith('sqlite:///'):
            db_path = db_uri.replace('sqlite:///', '')
            
            if not os.path.exists(db_path):
                return {'success': False, 'message': '数据库文件不存在'}
            
            # 创建备份目录
            backup_dir = get_backup_dir()
            
            # 生成备份文件名（带北京时间戳）
            try:
                if pytz:
                    tz = pytz.timezone('Asia/Shanghai')
                    now = datetime.now(tz)
                else:
                    from datetime import timedelta
                    now = datetime.utcnow() + timedelta(hours=8)
            except Exception:
                now = datetime.utcnow()
            timestamp = now.strftime('%Y%m%d_%H%M%S')
            backup_filename = f'app_backup_{timestamp}.db'
            backup_path = os.path.join(backup_dir, backup_filename)
            
            # 复制数据库文件
            shutil.copy2(db_path, backup_path)
            
            # 获取文件大小
            file_size = os.path.getsize(backup_path)
            
            return {
                'success': True,
                'message': '备份成功',
                'backup_path': backup_path,
                'backup_filename': backup_filename,
                'file_size': file_size,
                'timestamp': timestamp
            }
        else:
            return {'success': False, 'message': '当前仅支持 SQLite 数据库备份'}
    except Exception as e:
        return {'success': False, 'message': f'备份失败: {str(e)}'}


def restore_database(backup_filename):
    """恢复数据库"""
    try:
        from flask import has_app_context, current_app
        if not has_app_context():
            return {'success': False, 'message': '需要在应用上下文中执行'}
        db_uri = current_app.config['SQLALCHEMY_DATABASE_URI']
        
        if db_uri.startswith('sqlite:///'):
            db_path = db_uri.replace('sqlite:///', '')
            backup_dir = get_backup_dir()
            backup_path = os.path.join(backup_dir, backup_filename)
            
            if not os.path.exists(backup_path):
                return {'success': False, 'message': '备份文件不存在'}
            
            # 备份当前数据库（如果存在）
            if os.path.exists(db_path):
                current_backup = f"{db_path}.before_restore_{datetime.now().strftime('%Y%m%d_%H%M%S')}"
                shutil.copy2(db_path, current_backup)
            
            # 恢复数据库
            shutil.copy2(backup_path, db_path)
            
            return {
                'success': True,
                'message': '恢复成功',
                'backup_used': backup_filename
            }
        else:
            return {'success': False, 'message': '当前仅支持 SQLite 数据库恢复'}
    except Exception as e:
        return {'success': False, 'message': f'恢复失败: {str(e)}'}


def reset_database():
    """重置数据库（删除所有表并重新创建）
    
    保留的系统基础数据：
    1. 管理员账户 (admin/admin123，超级管理员不属于任何部门)
    2. 默认部门 (信息部、财务部、人力行政部、国内销售中心、生产办、企管部)
    3. 设备类型 (15种常用设备类型)
    4. 配件类型 (20种常用配件类型)
    5. 审批流程模板 (6种标准审批流程)
    """
    try:
        from flask import has_app_context
        if not has_app_context():
            return {'success': False, 'message': '需要在应用上下文中执行'}
        from app import db
        
        # 删除所有表
        db.drop_all()
        
        # 重新创建所有表
        db.create_all()
        
        # 使用新的系统数据初始化脚本
        from init_system_data import (
            init_departments, init_admin_user, init_equipment_types,
            init_spare_part_types, init_workflow_templates
        )
        
        # 依次初始化基础数据
        init_departments()
        db.session.commit()
        
        admin = init_admin_user()
        db.session.commit()
        
        init_equipment_types()
        db.session.commit()
        
        init_spare_part_types()
        db.session.commit()
        
        init_workflow_templates(admin.id)
        db.session.commit()
        
        return {
            'success': True,
            'message': '数据库重置成功，已重新初始化系统基础数据',
            'details': {
                'admin_username': 'admin',
                'admin_password': 'admin123',
                'admin_note': '超级管理员，不属于任何部门',
                'departments': '6个默认部门',
                'equipment_types': '15种设备类型',
                'spare_part_types': '20种配件类型',
                'workflow_templates': '6个审批流程模板'
            }
        }
    except Exception as e:
        import traceback
        return {'success': False, 'message': f'重置失败: {str(e)}', 'trace': traceback.format_exc()}


def list_backups(filter_date=None):
    """列出所有备份文件
    
    Args:
        filter_date: 筛选日期，可选值：'today', 'yesterday', 'week', 'month', 'all' 或 None（默认全部）
    """
    try:
        backup_dir = get_backup_dir()
        
        if not os.path.exists(backup_dir):
            return {'success': True, 'backups': [], 'total': 0}
        
        backups = []
        # use Asia/Shanghai aware now when possible
        try:
            if ZoneInfo:
                now = datetime.now(ZoneInfo('Asia/Shanghai'))
            elif pytz:
                now = datetime.now(pytz.timezone('Asia/Shanghai'))
            else:
                now = datetime.utcnow() + timedelta(hours=8)
        except Exception:
            now = datetime.utcnow()
        
        for filename in os.listdir(backup_dir):
            if filename.startswith('app_backup_') and filename.endswith('.db'):
                filepath = os.path.join(backup_dir, filename)
                file_stat = os.stat(filepath)
                # 将文件时间转换为北京时间显示，兼容无 pytz 情况
                try:
                    mtime = file_stat.st_mtime
                    # interpret mtime as UTC then convert to Asia/Shanghai when possible
                    if ZoneInfo:
                        created_dt = datetime.fromtimestamp(mtime, timezone.utc).astimezone(ZoneInfo('Asia/Shanghai'))
                    elif pytz:
                        created_dt = datetime.fromtimestamp(mtime, pytz.utc).astimezone(pytz.timezone('Asia/Shanghai'))
                    else:
                        created_dt = datetime.utcfromtimestamp(mtime) + timedelta(hours=8)
                except Exception:
                    created_dt = datetime.fromtimestamp(file_stat.st_mtime)
                
                # 日期筛选
                if filter_date:
                    if filter_date == 'today':
                        if created_dt.date() != now.date():
                            continue
                    elif filter_date == 'yesterday':
                        from datetime import timedelta
                        yesterday = now.date() - timedelta(days=1)
                        if created_dt.date() != yesterday:
                            continue
                    elif filter_date == 'week':
                        from datetime import timedelta
                        week_ago = now - timedelta(days=7)
                        if created_dt < week_ago:
                            continue
                    elif filter_date == 'month':
                        from datetime import timedelta
                        month_ago = now - timedelta(days=30)
                        if created_dt < month_ago:
                            continue
                
                # 提取时间戳（从文件名中）
                timestamp_str = filename.replace('app_backup_', '').replace('.db', '')
                
                # 格式化友好时间显示 (注意 created_dt 可能是 timezone-aware or naive)
                # Make created_dt timezone-aware in the same tz as now when possible
                try:
                    if created_dt.tzinfo is None:
                        if ZoneInfo:
                            created_dt = created_dt.replace(tzinfo=ZoneInfo('Asia/Shanghai'))
                        elif pytz:
                            created_dt = pytz.timezone('Asia/Shanghai').localize(created_dt)
                except Exception:
                    pass

                time_diff = now - created_dt
                if time_diff.days == 0:
                    if time_diff.seconds < 3600:  # 1小时内
                        if time_diff.seconds < 60:
                            friendly_time = f'刚刚 ({created_dt.strftime("%H:%M:%S")})'
                        else:
                            friendly_time = f'{time_diff.seconds // 60}分钟前 ({created_dt.strftime("%H:%M:%S")})'
                    else:
                        friendly_time = f'今天 {created_dt.strftime("%H:%M:%S")}'
                elif time_diff.days == 1:
                    friendly_time = f'昨天 {created_dt.strftime("%H:%M:%S")}'
                elif time_diff.days < 7:
                    friendly_time = f'{time_diff.days}天前 ({created_dt.strftime("%m-%d %H:%M")})'
                else:
                    friendly_time = created_dt.strftime('%Y-%m-%d %H:%M:%S')
                
                backups.append({
                    'filename': filename,
                    'size': file_stat.st_size,
                    'created': created_dt.strftime('%Y-%m-%d %H:%M:%S'),
                    'friendly_time': friendly_time,
                    'timestamp': file_stat.st_mtime,
                    'timestamp_str': timestamp_str,
                    'date': created_dt.date().isoformat()
                })
        
        # 按创建时间倒序排列
        backups.sort(key=lambda x: x['timestamp'], reverse=True)
        
        return {'success': True, 'backups': backups, 'total': len(backups)}
    except Exception as e:
        return {'success': False, 'message': f'获取备份列表失败: {str(e)}', 'backups': [], 'total': 0}


def delete_backup(backup_filename):
    """删除备份文件"""
    try:
        backup_dir = get_backup_dir()
        backup_path = os.path.join(backup_dir, backup_filename)
        
        if not os.path.exists(backup_path):
            return {'success': False, 'message': '备份文件不存在'}
        
        if not backup_filename.startswith('app_backup_') or not backup_filename.endswith('.db'):
            return {'success': False, 'message': '无效的备份文件名'}
        
        os.remove(backup_path)
        
        return {'success': True, 'message': '备份文件删除成功'}
    except Exception as e:
        return {'success': False, 'message': f'删除失败: {str(e)}'}


def get_database_info():
    """获取数据库信息"""
    try:
        from flask import has_app_context, current_app
        if not has_app_context():
            return {'success': False, 'message': '需要在应用上下文中执行'}
        from app import db
        from sqlalchemy import inspect
        
        db_uri = current_app.config['SQLALCHEMY_DATABASE_URI']
        
        info = {
            'type': 'SQLite' if db_uri.startswith('sqlite:///') else 'Unknown',
            'uri': db_uri.split('@')[-1] if '@' in db_uri else db_uri.replace('sqlite:///', '')
        }
        
        if db_uri.startswith('sqlite:///'):
            db_path = db_uri.replace('sqlite:///', '')
            if os.path.exists(db_path):
                info['exists'] = True
                info['size'] = os.path.getsize(db_path)
                # format mtime in Asia/Shanghai
                try:
                    mtime = os.path.getmtime(db_path)
                    if ZoneInfo:
                        modified_dt = datetime.fromtimestamp(mtime, timezone.utc).astimezone(ZoneInfo('Asia/Shanghai'))
                    elif pytz:
                        modified_dt = datetime.fromtimestamp(mtime, pytz.utc).astimezone(pytz.timezone('Asia/Shanghai'))
                    else:
                        modified_dt = datetime.utcfromtimestamp(mtime) + timedelta(hours=8)
                    info['modified'] = modified_dt.strftime('%Y-%m-%d %H:%M:%S')
                except Exception:
                    info['modified'] = datetime.fromtimestamp(os.path.getmtime(db_path)).strftime('%Y-%m-%d %H:%M:%S')
            else:
                info['exists'] = False
        
        # 获取表信息
        try:
            engine = db.engine
            insp = inspect(engine)
            info['tables'] = insp.get_table_names()
            info['table_count'] = len(info['tables'])
        except Exception:
            info['tables'] = []
            info['table_count'] = 0
        
        return {'success': True, 'info': info}
    except Exception as e:
        return {'success': False, 'message': f'获取数据库信息失败: {str(e)}'}

def export_database_to_mysql(sqlite_path, out_dir=None, src_tz='UTC', dst_tz='Asia/Shanghai'):
    """调用脚本将 SQLite 导出为 MySQL 兼容 SQL 文件，返回生成的文件名。"""
    try:
        if out_dir is None:
            out_dir = os.path.join(os.path.dirname(os.path.dirname(os.path.dirname(__file__))), 'migrations')
        os.makedirs(out_dir, exist_ok=True)
        # 生成输出文件名
        try:
            if pytz:
                now = datetime.now(pytz.timezone('Asia/Shanghai'))
            else:
                from datetime import timedelta
                now = datetime.utcnow() + timedelta(hours=8)
        except Exception:
            now = datetime.utcnow()
        out_name = f'app_db_mysql_dump_{now.strftime("%Y%m%d_%H%M%S")}.sql'
        out_path = os.path.join(out_dir, out_name)

        PROJECT_ROOT = os.path.abspath(os.path.join(os.path.dirname(__file__), '..', '..'))
        script = os.path.join(PROJECT_ROOT, 'scripts', 'sqlite_to_mysql.py')
        cmd = [sys.executable, script, '--sqlite', sqlite_path, '--out', out_path, '--src-tz', src_tz, '--dst-tz', dst_tz]
        proc = subprocess.run(cmd, stdout=subprocess.PIPE, stderr=subprocess.PIPE, text=True)
        if proc.returncode != 0:
            return {'success': False, 'message': proc.stderr}
        return {'success': True, 'dump_path': out_path, 'dump_filename': out_name}
    except Exception as e:
        return {'success': False, 'message': str(e)}


def export_database_to_mssql(sqlite_path, out_dir=None, src_tz='UTC', dst_tz='Asia/Shanghai'):
    """调用脚本将 SQLite 导出为 SQL Server 兼容 SQL 文件，返回生成的文件名。"""
    try:
        if out_dir is None:
            out_dir = os.path.join(os.path.dirname(os.path.dirname(os.path.dirname(__file__))), 'migrations')
        os.makedirs(out_dir, exist_ok=True)
        try:
            if pytz:
                now = datetime.now(pytz.timezone('Asia/Shanghai'))
            else:
                from datetime import timedelta
                now = datetime.utcnow() + timedelta(hours=8)
        except Exception:
            now = datetime.utcnow()
        out_name = f'app_db_mssql_dump_{now.strftime("%Y%m%d_%H%M%S")}.sql'
        out_path = os.path.join(out_dir, out_name)

        PROJECT_ROOT = os.path.abspath(os.path.join(os.path.dirname(__file__), '..', '..'))
        script = os.path.join(PROJECT_ROOT, 'scripts', 'sqlite_to_mssql.py')
        cmd = [sys.executable, script, '--sqlite', sqlite_path, '--out', out_path, '--src-tz', src_tz, '--dst-tz', dst_tz]
        proc = subprocess.run(cmd, stdout=subprocess.PIPE, stderr=subprocess.PIPE, text=True)
        if proc.returncode != 0:
            return {'success': False, 'message': proc.stderr}
        return {'success': True, 'dump_path': out_path, 'dump_filename': out_name}
    except Exception as e:
        return {'success': False, 'message': str(e)}


def export_database_to_postgresql(sqlite_path, out_dir=None, src_tz='UTC', dst_tz='Asia/Shanghai'):
    """调用脚本将 SQLite 导出为 PostgreSQL 兼容 SQL 文件，返回生成的文件名。"""
    try:
        if out_dir is None:
            out_dir = os.path.join(os.path.dirname(os.path.dirname(os.path.dirname(__file__))), 'migrations')
        os.makedirs(out_dir, exist_ok=True)
        try:
            if pytz:
                now = datetime.now(pytz.timezone('Asia/Shanghai'))
            else:
                from datetime import timedelta
                now = datetime.utcnow() + timedelta(hours=8)
        except Exception:
            now = datetime.utcnow()
        out_name = f'app_db_postgresql_dump_{now.strftime("%Y%m%d_%H%M%S")}.sql'
        out_path = os.path.join(out_dir, out_name)

        PROJECT_ROOT = os.path.abspath(os.path.join(os.path.dirname(__file__), '..', '..'))
        script = os.path.join(PROJECT_ROOT, 'scripts', 'sqlite_to_postgresql.py')
        cmd = [sys.executable, script, '--sqlite', sqlite_path, '--out', out_path, '--src-tz', src_tz, '--dst-tz', dst_tz]
        proc = subprocess.run(cmd, stdout=subprocess.PIPE, stderr=subprocess.PIPE, text=True)
        if proc.returncode != 0:
            return {'success': False, 'message': proc.stderr}
        return {'success': True, 'dump_path': out_path, 'dump_filename': out_name}
    except Exception as e:
        return {'success': False, 'message': str(e)}


def validate_database_file(file_path):
    """验证数据库文件是否有效"""
    try:
        if not os.path.exists(file_path):
            return {'success': False, 'message': '文件不存在'}
        
        # 检查文件大小
        file_size = os.path.getsize(file_path)
        if file_size == 0:
            return {'success': False, 'message': '文件为空'}
        
        # 尝试连接数据库
        import sqlite3
        conn = sqlite3.connect(file_path)
        cursor = conn.cursor()
        
        # 检查是否是有效的SQLite数据库
        try:
            cursor.execute("SELECT name FROM sqlite_master WHERE type='table'")
            tables = cursor.fetchall()
            table_count = len(tables)
        except Exception as e:
            conn.close()
            return {'success': False, 'message': f'不是有效的SQLite数据库: {str(e)}'}
        
        conn.close()
        
        return {
            'success': True,
            'message': '数据库文件有效',
            'file_size': file_size,
            'table_count': table_count,
            'tables': [t[0] for t in tables]
        }
    except Exception as e:
        return {'success': False, 'message': f'验证失败: {str(e)}'}


def get_table_chinese_name(table_name):
    """获取数据表的中文名称"""
    table_names = {
        'user': '用户表',
        'department': '部门表',
        'equipment': '设备表',
        'spare_part': '配件表',
        'spare_part_type': '配件类型表',
        'equipment_type': '设备类型表',
        'repair_order': '维修工单表',
        'part_request_order': '配件申请表',
        'part_replacement': '配件更换表',
        'equipment_transfer': '设备调拨表',
        'equipment_scrap': '设备报废表',
        'equipment_loan': '设备借用表',
        'equipment_application': '设备申领表',
        'notification': '通知表',
        'user_activity_log': '用户操作日志表',
        'approval_workflow': '审批流程表',
        'approval_decision': '审批决策表',
        'workflow_node': '审批节点表',
        'workflow_template': '审批流模板表',
        'account_request': '账号申请表',
        'asset_cost': '资产成本表',
        'asset_lifecycle': '资产生命周期表',
        'asset_handover': '资产交接表',
        'inventory_warning': '库存预警表',
        'lifecycle_event': '生命周期事件表',
        'permission': '权限表',
        'role_definition': '角色定义表',
        'user_custom_role': '用户自定义角色表',
        'action_log': '操作日志表',
        'audit_log': '审计日志表',
        'workflow_instance': '工作流实例表',
        'workflow_step': '工作流步骤表',
        'alembic_version': '数据库版本表',
    }
    return table_names.get(table_name, table_name)


def get_database_tables_info():
    """获取数据库中所有表的详细信息(表名和记录数)"""
    try:
        from flask import has_app_context, current_app
        if not has_app_context():
            return {'success': False, 'message': '需要在应用上下文中执行'}
        from app import db
        from sqlalchemy import inspect, text
        
        engine = db.engine
        insp = inspect(engine)
        tables = insp.get_table_names()
        
        tables_info = []
        total_records = 0
        
        with engine.connect() as conn:
            for table_name in tables:
                try:
                    # 获取记录数
                    result = conn.execute(text(f'SELECT COUNT(*) FROM "{table_name}"'))
                    count = result.scalar()
                    total_records += count
                    
                    # 获取列信息
                    columns = insp.get_columns(table_name)
                    column_count = len(columns)
                    
                    tables_info.append({
                        'name': table_name,
                        'chinese_name': get_table_chinese_name(table_name),
                        'record_count': count,
                        'column_count': column_count,
                        'columns': [col['name'] for col in columns]
                    })
                except Exception as e:
                    tables_info.append({
                        'name': table_name,
                        'chinese_name': get_table_chinese_name(table_name),
                        'record_count': 0,
                        'column_count': 0,
                        'columns': [],
                        'error': str(e)
                    })
        
        # 按记录数排序
        tables_info.sort(key=lambda x: x['record_count'], reverse=True)
        
        return {
            'success': True,
            'tables': tables_info,
            'table_count': len(tables_info),
            'total_records': total_records
        }
    except Exception as e:
        return {'success': False, 'message': f'获取表信息失败: {str(e)}'}


def get_table_data(table_name, page=1, per_page=50):
    """获取指定表的数据(分页)"""
    try:
        from flask import has_app_context, current_app
        if not has_app_context():
            return {'success': False, 'message': '需要在应用上下文中执行'}
        from app import db
        from sqlalchemy import inspect, text
        
        engine = db.engine
        insp = inspect(engine)
        
        # 检查表是否存在
        tables = insp.get_table_names()
        if table_name not in tables:
            return {'success': False, 'message': f'表 {table_name} 不存在'}
        
        # 获取列信息
        columns = insp.get_columns(table_name)
        column_names = [col['name'] for col in columns]
        
        with engine.connect() as conn:
            # 获取总记录数
            result = conn.execute(text(f'SELECT COUNT(*) FROM "{table_name}"'))
            total_count = result.scalar()
            
            # 分页查询数据
            offset = (page - 1) * per_page
            result = conn.execute(text(f'SELECT * FROM "{table_name}" LIMIT {per_page} OFFSET {offset}'))
            rows = result.fetchall()
            
            # 转换为字典列表
            data = []
            for row in rows:
                row_dict = {}
                for i, col_name in enumerate(column_names):
                    value = row[i]
                    # 处理None值和长文本
                    if value is None:
                        row_dict[col_name] = None
                    elif isinstance(value, str) and len(value) > 100:
                        row_dict[col_name] = value[:100] + '...'
                    else:
                        row_dict[col_name] = value
                data.append(row_dict)
            
            total_pages = (total_count + per_page - 1) // per_page
            
            return {
                'success': True,
                'table_name': table_name,
                'columns': column_names,
                'column_info': columns,
                'data': data,
                'total_count': total_count,
                'page': page,
                'per_page': per_page,
                'total_pages': total_pages
            }
    except Exception as e:
        return {'success': False, 'message': f'获取表数据失败: {str(e)}'}


