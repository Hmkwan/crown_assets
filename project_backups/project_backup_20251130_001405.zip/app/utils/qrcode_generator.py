"""
二维码生成工具模块
用于生成资产/配件的二维码标签
"""
import qrcode
from io import BytesIO
from PIL import Image, ImageDraw, ImageFont
import base64


def generate_qrcode(data, size=200, border=2):
    """
    生成二维码图片
    
    Args:
        data: 要编码的数据（字符串）
        size: 二维码尺寸（像素）
        border: 边框大小
    
    Returns:
        PIL Image 对象
    """
    qr = qrcode.QRCode(
        version=1,
        error_correction=qrcode.constants.ERROR_CORRECT_L,
        box_size=10,
        border=border,
    )
    qr.add_data(data)
    qr.make(fit=True)
    
    img = qr.make_image(fill_color="black", back_color="white")
    img = img.resize((size, size), Image.Resampling.LANCZOS)
    return img


def generate_asset_label(asset_type, asset_id, asset_name, asset_code, 
                         department=None, purchase_date=None, location=None, 
                         size_mm=(70, 70), dpi=300):
    """
    生成资产标签（70*70mm）- 完整显示版
    
    Args:
        asset_type: 资产类型 ('equipment' 或 'spare_part')
        asset_id: 资产ID
        asset_name: 资产名称
        asset_code: 资产编码/序列号
        department: 所属部门（可选）
        purchase_date: 采购日期（可选）
        location: 存放位置（可选）
        size_mm: 标签尺寸（毫米），默认70*70mm
        dpi: 打印分辨率，默认300dpi
    
    Returns:
        PIL Image 对象
    """
    # 转换为像素（1英寸=25.4毫米）
    width_px = int(size_mm[0] * dpi / 25.4)
    height_px = int(size_mm[1] * dpi / 25.4)
    
    # 创建画布（白色背景）
    img = Image.new('RGB', (width_px, height_px), 'white')
    draw = ImageDraw.Draw(img)
    
    # 计算边距 - 最小化边距
    margin = int(width_px * 0.03)  # 3%边距
    
    # 绘制顶部标题栏
    header_height = int(height_px * 0.09)
    draw.rectangle([(0, 0), (width_px, header_height)], fill='#2c3e50')
    
    # 尝试加载中文字体
    font_title = None
    font_bold = None
    font_normal = None
    font_small = None
    
    font_paths = [
        "C:/Windows/Fonts/msyhbd.ttc",  # 微软雅黑 Bold
        "C:/Windows/Fonts/msyh.ttc",    # 微软雅黑
        "C:/Windows/Fonts/simhei.ttf",  # 黑体
        "C:/Windows/Fonts/simsun.ttc",  # 宋体
    ]
    
    for font_path in font_paths:
        try:
            font_title = ImageFont.truetype(font_path, int(height_px * 0.06))
            font_bold = ImageFont.truetype(font_path, int(height_px * 0.05))
            font_normal = ImageFont.truetype(font_path, int(height_px * 0.045))
            font_small = ImageFont.truetype(font_path, int(height_px * 0.038))
            break
        except:
            continue
    
    if font_title is None:
        try:
            font_title = ImageFont.truetype("arial.ttf", int(height_px * 0.06))
            font_bold = ImageFont.truetype("arialbd.ttf", int(height_px * 0.05))
            font_normal = ImageFont.truetype("arial.ttf", int(height_px * 0.045))
            font_small = ImageFont.truetype("arial.ttf", int(height_px * 0.038))
        except:
            font_title = ImageFont.load_default()
            font_bold = ImageFont.load_default()
            font_normal = ImageFont.load_default()
            font_small = ImageFont.load_default()
    
    # 绘制标题文字
    title_text = "设备标签" if asset_type == 'equipment' else "配件标签"
    try:
        bbox = draw.textbbox((0, 0), title_text, font=font_title)
        title_width = bbox[2] - bbox[0]
    except:
        title_width = len(title_text) * int(height_px * 0.035)
    
    title_x = (width_px - title_width) // 2
    title_y = (header_height - int(height_px * 0.06)) // 2
    draw.text((title_x, title_y), title_text, fill='white', font=font_title)
    
    # 生成二维码 - 占左侧50%宽度
    qr_data = f"{asset_type}:{asset_id}:{asset_code}"
    qr_size = int(width_px * 0.50)
    qr_img = generate_qrcode(qr_data, size=qr_size, border=1)
    
    # 二维码位置
    qr_x = margin
    qr_y = header_height + int(margin * 0.8)
    
    # 绘制二维码边框
    border_width = 2
    draw.rectangle(
        [(qr_x - border_width, qr_y - border_width), 
         (qr_x + qr_size + border_width, qr_y + qr_size + border_width)],
        outline='#3498db',
        width=border_width
    )
    
    # 粘贴二维码
    img.paste(qr_img, (qr_x, qr_y))
    
    # 文本区域（右侧）
    text_x = qr_x + qr_size + int(margin * 1.5)
    text_y = header_height + int(margin * 0.8)
    text_width = width_px - text_x - margin
    
    # 准备文本内容
    info_items = []
    
    # 设备名称
    name_display = asset_name if len(asset_name) <= 6 else asset_name[:6] + ".."
    info_items.append(('name', name_display, font_bold, '#2c3e50'))
    
    # 分隔线
    info_items.append(('divider', None, None, None))
    
    # 编码
    code_display = asset_code if len(asset_code) <= 9 else asset_code[:9] + ".."
    info_items.append(('编码', code_display, font_normal, '#34495e'))
    
    # 部门
    dept_display = department if department and len(department) <= 5 else (department[:5] + ".." if department and len(department) > 5 else "未分配")
    info_items.append(('部门', dept_display, font_normal, '#34495e'))
    
    # 采购日期
    if purchase_date:
        date_text = purchase_date if isinstance(purchase_date, str) else purchase_date.strftime('%Y-%m-%d')
    else:
        date_text = "未录入"
    info_items.append(('采购', date_text, font_small, '#7f8c8d'))
    
    # 存放位置
    if location:
        loc_display = location if len(location) <= 7 else location[:7] + ".."
    else:
        loc_display = "未指定"
    info_items.append(('位置', loc_display, font_normal, '#e74c3c'))
    
    # 绘制文本信息
    current_y = text_y
    line_spacing = int(height_px * 0.07)  # 行间距
    
    for item in info_items:
        if item[0] == 'divider':
            # 分隔线
            current_y += int(line_spacing * 0.2)
            draw.line(
                [(text_x, current_y), (width_px - margin, current_y)],
                fill='#bdc3c7',
                width=1
            )
            current_y += int(line_spacing * 0.35)
        elif item[0] == 'name':
            # 设备名称
            draw.text((text_x, current_y), item[1], fill=item[3], font=item[2])
            current_y += line_spacing
        else:
            # 标签: 值格式
            label_text = f"{item[0]}:"
            value_text = item[1]
            
            # 标签
            draw.text((text_x, current_y), label_text, fill='#95a5a6', font=font_small)
            
            # 值
            try:
                bbox = draw.textbbox((0, 0), label_text, font=font_small)
                label_width = bbox[2] - bbox[0]
            except:
                label_width = len(label_text) * int(height_px * 0.02)
            
            value_x = text_x + label_width + int(margin * 0.3)
            draw.text((value_x, current_y), value_text, fill=item[3], font=item[2])
            current_y += line_spacing
    
    # 底部装饰线 - 固定在底部上方
    footer_y = height_px - int(height_px * 0.08)
    draw.line(
        [(margin, footer_y), (width_px - margin, footer_y)],
        fill='#3498db',
        width=2
    )
    
    # 底部信息 - 确保完整显示
    bottom_y = footer_y + int(margin * 0.6)
    
    # 左下角：资产类型
    icon_text = "设备" if asset_type == 'equipment' else "配件"
    draw.text((margin, bottom_y), icon_text, fill='#7f8c8d', font=font_small)
    
    # 右下角：ID标识
    id_text = f"ID:{asset_id}"
    try:
        bbox = draw.textbbox((0, 0), id_text, font=font_small)
        id_width = bbox[2] - bbox[0]
    except:
        id_width = len(id_text) * int(height_px * 0.02)
    
    id_x = width_px - margin - id_width
    draw.text((id_x, bottom_y), id_text, fill='#7f8c8d', font=font_small)
    
    return img


def image_to_base64(img, format='PNG'):
    """
    将PIL图片转换为base64字符串（用于在线预览）
    
    Args:
        img: PIL Image 对象
        format: 图片格式
    
    Returns:
        base64编码的字符串
    """
    buffer = BytesIO()
    img.save(buffer, format=format)
    img_str = base64.b64encode(buffer.getvalue()).decode()
    return f"data:image/{format.lower()};base64,{img_str}"


def image_to_bytes(img, format='PNG'):
    """
    将PIL图片转换为字节流（用于下载）
    
    Args:
        img: PIL Image 对象
        format: 图片格式
    
    Returns:
        BytesIO 对象
    """
    buffer = BytesIO()
    img.save(buffer, format=format)
    buffer.seek(0)
    return buffer

